import processing.core.PApplet;
import processing.core.PImage;

public class Principal extends PApplet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PApplet.main("Principal");

	}

	@Override
	public void settings() {
		size(1200, 700);

	}

	PImage fondo7;

	PImage personaje;
	PImage cofre;
	PImage corazon;

	Cuadros cuadro1;
	Cuadros cuadro2;
	Cuadros cuadro3;
	Cuadros cuadro4;
	Cuadros cuadro5;

	Piezas p1;
	Piezas p2;
	Piezas p3;
	Piezas p4;
	Piezas p5;

	Piezas pi1;
	Piezas pi2;
	Piezas pi3;
	Piezas pi4;
	Piezas pi5;

	int puntos;

	@Override
	public void setup() {

		fondo7 = loadImage("NIVEL 7.png");
		
		corazon = loadImage("corazon.png");

		personaje = loadImage("min2.png");
		cofre = loadImage("cofre.png");
		corazon = loadImage("corazon.png");

		cuadro1 = new Cuadros(720, 147, 124, 374);
		cuadro2 = new Cuadros(844, 147, 124, 125);
		cuadro3 = new Cuadros(968, 147, 124, 125);
		cuadro4 = new Cuadros(844, 271, 248, 125);
		cuadro5 = new Cuadros(844, 396, 248, 125);

		p1 = new Piezas(this, 422, 91);
		p2 = new Piezas(this, 555, 91);
		p3 = new Piezas(this, 555, 239);
		p4 = new Piezas(this, 555,394);
		p5 = new Piezas(this, 133,91);

		pi1 = null;
		pi2 = null;
		pi3 = null;
		pi4 = null;
		pi5 = null;

		puntos = 0;

	}

	@Override
	public void draw() {

		background(255);

		image(fondo7, 0, 0);

		cuadro1.pintar(this);
		cuadro2.pintar(this);
		cuadro3.pintar(this);
		cuadro4.pintar(this);
		cuadro5.pintar(this);

		personaje.resize(0, 400);
		imageMode(CENTER);
		image(personaje, 270, 400);
		imageMode(CORNER);
		
		p1.pintar1(this);
		p2.pintar2(this);
		p3.pintar3(this);
		p4.pintar4(this);
		p5.pintar5(this);
		
		
		if (puntos == 5) {
			
			
			
			corazon.resize(0, 100);
			image(corazon, 250, 150);
			
			
		}
		
		System.out.println(puntos);

	}

	@Override
	public void mousePressed() {

		if (dist(mouseX, mouseY, p1.getX(), p1.getY()) < 40) {

			pi1 = p1;
		}

		if (dist(mouseX, mouseY, p2.getX(), p2.getY()) < 64) {

			pi2 = p2;
		}

		if (dist(mouseX, mouseY, p3.getX(), p3.getY()) < 40) {

			pi3 = p3;
		}

		if (dist(mouseX, mouseY, p4.getX(), p4.getY()) < 40) {

			pi4 = p4;
		}

		if (dist(mouseX, mouseY, p5.getX(), p5.getY()) < 40) {

			pi5 = p5;
		}

	}

	public void mouseDragged() {

		if (pi1 != null) {

			p1.setX(mouseX);
			p1.setY(mouseY);

		}

		if (pi2 != null) {

			p2.setX(mouseX);
			p2.setY(mouseY);

		}

		if (pi3 != null) {

			p3.setX(mouseX);
			p3.setY(mouseY);

		}

		if (pi4 != null) {

			p4.setX(mouseX);
			p4.setY(mouseY);

		}

		if (pi5 != null) {

			p5.setX(mouseX);
			p5.setY(mouseY);

		}

	}

	@Override
	public void mouseReleased() {

		if (p1.getX() > cuadro1.getX() && p1.getX() < cuadro1.getX() + 124 && p1.getY() > cuadro1.getY()
				&& p1.getY() < cuadro1.getY() + 374) {

			p1 = new Piezas(this, 720, 147);
			pi1 = null;
			puntos +=1;

		}

		if (p2.getX() > cuadro2.getX() && p2.getX() < cuadro2.getX() + 124 && p2.getY() > cuadro2.getY()
				&& p2.getY() < cuadro2.getY() + 125) {

			p2 = new Piezas(this, 844, 147);
			pi2 = null;
			puntos +=1;

		}

		if (p3.getX() > cuadro3.getX() && p3.getX() < cuadro3.getX() + 124 && p3.getY() > cuadro3.getY()
				&& p3.getY() < cuadro3.getY() + 125) {

			p3 = new Piezas(this, 968, 147);
			pi3 = null;
			puntos +=1;

		}

		if (p4.getX() > cuadro4.getX() && p4.getX() < cuadro4.getX() + 248 && p4.getY() > cuadro4.getY()
				&& p4.getY() < cuadro4.getY() + 125) {

			p4 = new Piezas(this, 844, 271);
			pi4 = null;
			puntos +=1;

		}
		if (p5.getX() > cuadro5.getX() && p5.getX() < cuadro5.getX() + 248 && p5.getY() > cuadro5.getY()
				&& p5.getY() < cuadro5.getY() + 125) {

			p5 = new Piezas(this, 844, 396);
			pi5 = null;
			
			puntos +=1;
			

		}

	}
}
