import processing.core.PApplet;

public class Cuadros {
	private int x;
	private int y;
	private int lado1;
	private int lado2;
	
	
	public Cuadros() {
		this.x = 0;
		this.y = 0;
		this.lado1 = 200;
		this.lado1 = 200;

	}

	public Cuadros(int x, int y, int lado1, int lado2) {

		this.x = x;
		this.y = y;

		this.lado1 = lado1;
		this.lado2 = lado2;

	

	}

	public void pintar(PApplet app) {

		// app.fill(r, g, b);

		app.noFill();
	
		app.noStroke();
		app.rect(x, y, lado1, lado2);
		

		

	}
	
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
}
