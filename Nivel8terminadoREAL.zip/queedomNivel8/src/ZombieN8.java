import java.util.Set;

import processing.core.PApplet;
import processing.core.PImage;

public class ZombieN8 {
	int xZN8, yZN8;
	private PImage zombieIzq;
	private int speedN8;

	public ZombieN8(PApplet app, int x, int y) {

		zombieIzq = app.loadImage("zombieIzquierda.png");

		this.xZN8 = x;
		this.yZN8 = y;
		this.speedN8 = 2;
	}

	public void pintarZombie(PApplet app) {
		app.imageMode(app.CENTER);
		zombieIzq.resize(0, 140);
		app.image(zombieIzq, xZN8, yZN8);
		app.imageMode(app.CORNER);

	}

	public void moverZombie1(PApplet app) {

		xZN8 += speedN8;

		if (xZN8 >= 800) {
			xZN8 = 800;
			speedN8 -= 2;

		} else if (xZN8 <= 400) {
			xZN8 = 400;
			speedN8 = 2;
		}
	}

	public void moverZombie2(PApplet app) {

		xZN8 += speedN8;

		if (xZN8 >= 700) {
			xZN8 = 700;
			speedN8 -= 2;

		} else if (xZN8 <= 400) {
			xZN8 = 400;
			speedN8 = 2;
		}
	}

	public void moverZombie3(PApplet app) {

		xZN8 += speedN8;

		if (xZN8 >= 700) {
			xZN8 = 700;
			speedN8 -= 2;

		} else if (xZN8 <= 400) {
			xZN8 = 400;
			speedN8 = 2;
		}
	}

	public void moverZombie4(PApplet app) {

		xZN8 += speedN8;

		if (xZN8 >= 800) {
			xZN8 = 800;
			speedN8 -= 2;

		} else if (xZN8 <= 400) {
			xZN8 = 400;
			speedN8 = 2;
		}

}
	public int getxZN8() {
		return xZN8;
	}
	public int getyZN8() {
		return yZN8;
	}
	public void setxZN8(int xZN8) {
		this.xZN8 = xZN8;
	}
	public void setyZN8(int yZN8) {
		this.yZN8 = yZN8;
	}
	
}
