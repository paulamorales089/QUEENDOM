import processing.core.PApplet;
import processing.core.PImage;

public class SunnyN8 {
	int xSN8, ySN8;
	
	private PImage sunnyEspadaN8;
	private PImage sunnyEspadaIzqN8;
	private PImage sunnyDagaN8;
	private PImage sunnyDerechaN8;
	private int vida;

	public SunnyN8 (PApplet app,int x, int y) {
		
		sunnyEspadaN8 = app.loadImage("sunnyNegroEspada.png");
		sunnyDagaN8 = app.loadImage("sunnyNegroDaga.png");
		sunnyEspadaIzqN8 = app.loadImage("sunnyEspadaIzq.png");
		sunnyDerechaN8= app.loadImage("sunnyDerecha.png");

		this.xSN8 = x;
		this.ySN8 = y;
		this.vida=3;
	}
	public void pintarSunnyDerecha(PApplet app) {
		app.imageMode (app.CENTER);
		sunnyDerechaN8.resize(0, 170);
		app.image(sunnyDerechaN8, xSN8, ySN8);
		app.imageMode (app.CORNER);
	}
	public void pintarSunnyEspada(PApplet app) {
		app.imageMode (app.CENTER);
		sunnyEspadaN8.resize(0, 166);
		app.image(sunnyEspadaN8, xSN8, ySN8);
		app.imageMode (app.CORNER);
	}
	public void pintarSunnyDaga(PApplet app) {
		app.imageMode (app.CENTER);
		sunnyDagaN8.resize(0, 166);
		app.image(sunnyDagaN8, xSN8, ySN8);
		app.imageMode (app.CORNER);
	}
	public void moverArriba() {

		ySN8 -= 20;
	}

	public void moverAbajo() {

		ySN8 += 20;
	}
	
	public void moverAdelante() {

		xSN8 += 20;
	}
	public void moverAtras() {

		xSN8 -= 20;
	}
	
	public int getxSN8() {
		return xSN8;
	}

	public void setxSN8(int xSN8) {
		this.xSN8 = xSN8;
	}

	public int getySN8() {
		return ySN8;
	}

	public void setySN8(int ySN8) {
		this.ySN8 = ySN8;
	}
	
	boolean validarBala (int xBala, int yBala) {
		if(xBala>xSN8 && xBala<xSN8+47 && yBala>ySN8 && yBala<ySN8+47) {
			vida-=1;
			return true;
			
		}
		return false;

	}


}
