import processing.core.PApplet;
import processing.core.PImage;

public class principal extends PApplet {

	public static void main(String[] args) {
		PApplet.main("principal");
	}

	@Override
	public void settings() {
		size(1200, 700);
	}

	SunnyN8 sunny, sunnyEspada, sunnyDaga;
	ZombieN8 zombieN81, zombieN82, zombieN83, zombieN84;
	ReyZombieN8 reyZombie;
	Bala bala1, bala2, bala3, bala4, bala5, bala6;
	// FONDOS
	PImage NIVEL8;
	PImage GANO;
	PImage PERDIO;
	// perder
	int click = 2;
	boolean perder = true;
	int mostrar;
	boolean mostrar1 = true;
	boolean mostrar2 = true;
	boolean mostrar3 = true;
	boolean mostrar4 = true;
	boolean mostrar5 = true;
	//boolean de tapa corazones
	boolean mostrar6 = false;
	boolean mostrar7 = false;
	boolean mostrar8 = false;
	
	int espada = 0;
	int daga = 0;
	boolean moverAr1 = true;
	boolean moverAb1 = true;
	boolean moverAr2 = true;
	boolean moverAb2 = true;
	boolean moverAr3 = true;
	boolean moverAb3 = true;
	
	int toque = 0;
	int vidaSunny = 3;
	
	Arma arma1,arma2,arma3,arma4;
	Bala disparo1, disparo2, disparo3, disparo4;
	
	@Override
	public void setup() {
		// FONDOS NIVEL 8
		NIVEL8 = loadImage("NIVEL 8 bien.png");
		GANO = loadImage("GAN�.png");
		PERDIO = loadImage("PERDI�.png");
		// SUNNY NIVEL 8
		sunny = new SunnyN8(this, 120, 300);
		sunnyEspada = new SunnyN8(this, 120, 300);
		sunnyDaga = new SunnyN8(this, 120, 300);
		// ZOMBIES NORMALES NIVEL 8
		zombieN81 = new ZombieN8(this, 800, 230);
		zombieN82 = new ZombieN8(this, 700, 270);
		zombieN83 = new ZombieN8(this, 700, 380);
		zombieN84 = new ZombieN8(this, 800, 470);
		// REY ZOMBIE NIVEL 8
		reyZombie = new ReyZombieN8(this, 900, 310);
		// BALA NIVEL 8
		bala1 = new Bala(this, 350, 350);
		bala2 = new Bala(this, 350, 360);
		bala3 = new Bala(this, 350, 370);
		bala4 = new Bala(this, 350, 380);
		bala5 = new Bala(this, 350, 390);
		bala6 = new Bala(this, 350, 400);
		
		arma1 = new Arma(this);
		arma2 = new Arma(this);
		arma3 = new Arma(this);
		arma4 = new Arma(this);
		
		
	}

	@Override
	public void draw() {
		background(255);

		System.out.println(mouseX + "," + mouseY);
		//TIMER DISPAROS BALAS YEI
		int s=second();
		noFill();
		//textSize(20);
		text(s,570,20);
		
		
		//if (click == 0) {
			// FONDO
			image(NIVEL8, 0, 0);

// SUNNY
			sunny.pintarSunnyDerecha(this);
						
// BALA
			/*bala1.pintarBala(this);
			bala2.pintarBala(this);
			bala3.pintarBala(this);
			bala4.pintarBala(this);
			bala5.pintarBala(this);
			bala6.pintarBala(this);*/
//ARMA
			arma1.pintarArma1(this);
			arma2.pintarArma2(this);
			arma3.pintarArma3(this);
			arma4.pintarArma4(this);
			

			
//DISPAROS Y VIVAS DE SUNNY
			if(arma1.bala !=null && sunny.validarBala(arma1.bala.x, arma1.bala.y)==true) {
				arma1.bala=null;
				vidaSunny-=1;
			}

			if(arma2.bala !=null && sunny.validarBala(arma2.bala.x, arma2.bala.y)==true) {
				arma2.bala=null;
				vidaSunny-=1;
			}

			if(arma3.bala !=null && sunny.validarBala(arma3.bala.x, arma3.bala.y)==true) {
				arma3.bala=null;
				vidaSunny-=1;
			}

			if(arma4.bala !=null && sunny.validarBala(arma4.bala.x, arma4.bala.y)==true) {
				arma4.bala=null;
				vidaSunny-=1;
			}
			
//CADA CUANTO HAY DISPAROS LOKOS JUJU 
	if(s==6 || s==12 || s==18 || s==24 || s==30 || s==36 || s==42 ||s==48||s==54||s==60) {
		arma1.disparar1(this);
		arma2.disparar2(this);
		arma3.disparar3(this);
		arma4.disparar4(this);
	}
	
		
//PERDER NIVEL
			if(mostrar1==true) {
	if (dist(sunny.getxSN8(), sunny.getySN8(), zombieN81.getxZN8(), zombieN81.getyZN8()) < 50) {
		click = 1;
	}
			}
			if(mostrar2==true) {
	if (dist(sunny.getxSN8(), sunny.getySN8(), zombieN82.getxZN8(), zombieN82.getyZN8()) < 50) {
		click = 1;
	}
			}
			if(mostrar3==true) {
	if (dist(sunny.getxSN8(), sunny.getySN8(), zombieN83.getxZN8(), zombieN83.getyZN8()) < 50) {
		click = 1;
	}
	}
			if(mostrar4==true) {
	if (dist(sunny.getxSN8(), sunny.getySN8(), zombieN84.getxZN8(), zombieN84.getyZN8()) < 50) {
		click = 1;
	}
	}
			
			
//TAPA CORAZONES DE VIDAS SUNNY
	if(vidaSunny==2) {
		mostrar6=true;
	}
	if(vidaSunny==1) {
		mostrar7=true;
	}
	if(vidaSunny==0) {
		perder=false;
	}
	if(mostrar6==true) {
		fill(96,159,144);
		noStroke();
		square(772, 25, 30);
					
	}
	if(mostrar7==true) {
		fill(96,159,144);
		noStroke();
		square(805, 25, 30);

	}
	if(mostrar8==true) {
		fill(96,159,144);
		noStroke();
		square(838, 25, 30);
					
	}
					
	//PERDER CON EL REY
			if(mostrar5 == true) {
	if(dist(sunny.getxSN8(),sunny.getySN8(), reyZombie.getxRN8(), reyZombie.getyRN8())<100) {
		click = 1;
	}
			}
			
//GANAR
	if (sunny.getxSN8() > 1200) {
		click = 2;
	}
	
//GANAR IMAGEN
		/*	if (click == 2) {
		// carretera nivel 6
			image(GANO, 0, 0);
		}*/
	
	if (mostrar == 0) {
		sunnyEspada.pintarSunnyEspada(this);
		noFill();
		strokeWeight(1);
		stroke(255);
		rect(590, 13, 60, 52);
	}	

	if (mostrar == 1) {
		sunnyDaga.pintarSunnyDaga(this);
		noFill();
		strokeWeight(1);
		stroke(255);
		rect(690, 13, 60, 52);
	}
	if (mostrar1 == true) {
		zombieN81.pintarZombie(this);
		zombieN81.moverZombie1(this);
	}
	if (mostrar2 == true) {
		zombieN82.pintarZombie(this);
		zombieN82.moverZombie2(this);
	}
	if (mostrar3 == true) {
		zombieN83.pintarZombie(this);
		zombieN83.moverZombie3(this);
	}
	if (mostrar4 == true) {
		zombieN84.pintarZombie(this);
		zombieN84.moverZombie4(this);
	}
	if (mostrar5 == true) {
	reyZombie.pintarReyZombie(this);
	reyZombie.moverRey(this);
	}
	//PIEDE EL NIVEL Y SE REINICIA E IMAGEN
		if (click == 1) {
			image(PERDIO, 0, 0);
		
		}
	// CONTADOR DE CLICKS PARA MATA AL REY
		System.out.println(toque);
		if(toque==10) {
			mostrar5=false;
			perder =false;
		}
	
		
	}
	

	@Override
	public void mousePressed() {
	// seleccion de armas
		// espada
		if (dist(mouseX, mouseY, 622, 38) < 40) {
			// pintar Sunny con espada
			if (espada == 0) {
				mostrar = 0;
			}
		}
//DAGA
		if (dist(mouseX, mouseY, 717, 40) < 40) {
			// pintar Sunny con dagas
			if (daga == 0) {
				mostrar = 1;
			}
		}
		
		//perder
		/*if (dist(mouseX, mouseY, 618, 475) < 30) {
			click=0;
		}*/
		
//MATAR ZOMBIES
		
		if (mostrar==0 ) {
			// espada
			
		if (dist(mouseX, mouseY, zombieN81.getxZN8(), zombieN81.getyZN8()) < 100) {
			if (dist(sunnyEspada.getxSN8(), sunnyEspada.getySN8(), zombieN81.getxZN8(), zombieN81.getyZN8()) < 200) {
				mostrar1 = false;
				perder = false;		
			}
		}
		if (dist(mouseX, mouseY, zombieN82.getxZN8(), zombieN82.getyZN8()) < 100) {
			if (dist(sunnyEspada.getxSN8(), sunnyEspada.getySN8(), zombieN82.getxZN8(), zombieN82.getyZN8()) < 200) {
				mostrar2 = false;
				perder = false;
			}
		}
		if (dist(mouseX, mouseY, zombieN83.getxZN8(), zombieN83.getyZN8()) < 100) {
			if (dist(sunnyEspada.getxSN8(), sunnyEspada.getySN8(), zombieN83.getxZN8(), zombieN83.getyZN8()) < 200) {
				mostrar3 = false;
				perder = false;
			}
		}
			
		if (dist(mouseX, mouseY, zombieN84.getxZN8(), zombieN84.getyZN8()) < 100) {
			if (dist(sunnyEspada.getxSN8(), sunnyEspada.getySN8(), zombieN84.getxZN8(), zombieN84.getyZN8()) < 200) {
				mostrar4 = false;
				perder = false;
			}
		}
//MATAR A REY ZOMBIE CON ESPADA
		if(dist(mouseX,mouseY,reyZombie.getxRN8(),reyZombie.getyRN8())<200) {
			if (dist(sunnyEspada.getxSN8(), sunnyEspada.getySN8(), reyZombie.getxRN8(), reyZombie.getyRN8()) < 300) {
				//mostrar5 = false;
				//perder = false;
					toque += 1;
				}
			}
		}

		if (mostrar==1) {
			// daga
			if (dist(mouseX, mouseY, zombieN81.getxZN8(), zombieN81.getyZN8()) < 100) {
				if (dist(sunnyDaga.getxSN8(), sunnyDaga.getySN8(), zombieN81.getxZN8(), zombieN81.getyZN8()) < 100) {
					mostrar1 = false;
					perder = false;
				}
			}

			if (dist(mouseX, mouseY, zombieN82.getxZN8(), zombieN82.getyZN8()) < 100) {

				if (dist(sunnyDaga.getxSN8(), sunnyDaga.getySN8(), zombieN82.getxZN8(), zombieN82.getyZN8()) < 100) {
					mostrar2 = false;
					perder = false;
				}
			}
			if (dist(mouseX, mouseY, zombieN83.getxZN8(), zombieN83.getyZN8()) < 100) {
				if (dist(sunnyDaga.getxSN8(), sunnyDaga.getySN8(), zombieN83.getxZN8(), zombieN83.getyZN8()) < 100) {
					mostrar3 = false;
					perder = false;
				}
			}

			if (dist(mouseX, mouseY, zombieN84.getxZN8(), zombieN84.getyZN8()) < 100) {
				if (dist(sunnyDaga.getxSN8(), sunnyDaga.getySN8(), zombieN84.getxZN8(), zombieN84.getyZN8()) < 100) {
					mostrar4 = false;
					perder = false;
				}
			}
// MATAR A REY ZOMBIE CON DAGA
			if(dist(mouseX,mouseY,reyZombie.getxRN8(),reyZombie.getyRN8())<200) {
				if (dist(sunnyDaga.getxSN8(), sunnyDaga.getySN8(), reyZombie.getxRN8(), reyZombie.getyRN8()) < 200) {
					//mostrar5 = false;
				//perder = false;
				toque += 1;
				
				}
			}
		}
	}

	@Override
	public void keyPressed() {

		/* if (click == 0) { */
		if (moverAr1 == true) {
			if (key == 'w' || key == 'W') {
				sunny.moverArriba();
			}
		}
		if (moverAb1 == true) {
			if (key == 's' || key == 'S') {
				sunny.moverAbajo();
			}
		}
		if (key == 'd' || key == 'D') {
			sunny.moverAdelante();
		}
		if (key == 'a' || key == 'A') {
			sunny.moverAtras();
		}

		// LIMITACIONES PARA MOVERSE HACIA ARRIBA
		if (sunny.getxSN8() < 1200 && sunny.getySN8() < 180 && sunny.getxSN8() > 0 && sunny.getySN8() > 0) {
			moverAr1 = false;
		}
		if (sunny.getxSN8() < 1200 && sunny.getySN8() < 500 && sunny.getxSN8() > 0 && sunny.getySN8() > 180) {
			moverAr1 = true;
		}
		// LIMITACIONES PARA MOVERSE HACIA ABAJO
		if (sunny.getxSN8() < 1200 && sunny.getySN8() < 700 && sunny.getxSN8() > 0 && sunny.getySN8() > 475) {
			moverAb1 = false;
		}
		if (sunny.getxSN8() < 1200 && sunny.getySN8() < 475 && sunny.getxSN8() > 0 && sunny.getySN8() > 180) {
			moverAb1 = true;
		}

		if (click == 2) {

		if (espada == 0) {

		if (moverAr2 == true) {
		if (key == 'w' || key == 'W') {
			sunnyEspada.moverArriba();
			}
		}
		if (moverAb2 == true) {
		if (key == 's' || key == 'S') {
			sunnyEspada.moverAbajo();
		}
	}
		if (key == 'd' || key == 'D') {
			sunnyEspada.moverAdelante();
		}
		if (key == 'a' || key == 'A') {
			sunnyEspada.moverAtras();
		}

		// limitacion para moverse hacia arriba
		if (sunnyEspada.getxSN8() < 1200 && sunnyEspada.getySN8() < 180 && sunnyEspada.getxSN8() > 0
			&& sunnyEspada.getySN8() > 0) {
			moverAr2 = false;
		}
		if (sunnyEspada.getxSN8() < 1200 && sunnyEspada.getySN8() < 500 && sunnyEspada.getxSN8() > 0
			&& sunnyEspada.getySN8() > 180) {
			moverAr2 = true;
		}
		// limitacion para moverse hacia abajo
		if (sunnyEspada.getxSN8() < 1200 && sunnyEspada.getySN8() < 700 && sunnyEspada.getxSN8() > 0
			&& sunnyEspada.getySN8() > 475) {
			moverAb2 = false;
		}
		if (sunnyEspada.getxSN8() < 1200 && sunnyEspada.getySN8() < 475 && sunnyEspada.getxSN8() > 0
			&& sunnyEspada.getySN8() > 180) {
			moverAb2 = true;
		}
	}
}

		if (daga == 0) {
			if (moverAr3 == true) {
			if (key == 'w' || key == 'W') {
				sunnyDaga.moverArriba();
			}
		}
		if (moverAb3 == true) {
			if (key == 's' || key == 'S') {
				sunnyDaga.moverAbajo();
			}
		}
		if (key == 'd' || key == 'D') {
			sunnyDaga.moverAdelante();
		}
		if (key == 'a' || key == 'A') {
			sunnyDaga.moverAtras();
		}

		// limitacion para moverse hacia arriba
		if (sunnyDaga.getxSN8() < 1200 && sunnyDaga.getySN8() < 180 && sunnyDaga.getxSN8() > 0
			&& sunnyDaga.getySN8() > 0) {
			moverAr3 = false;
		}
		if (sunnyDaga.getxSN8() < 1200 && sunnyDaga.getySN8() < 500 && sunnyDaga.getxSN8() > 0
			&& sunnyDaga.getySN8() > 180) {
			moverAr3 = true;
		}
		// limitacion para moverse hacia abajo
		if (sunnyDaga.getxSN8() < 1200 && sunnyDaga.getySN8() < 700 && sunnyDaga.getxSN8() > 0
			&& sunnyDaga.getySN8() > 475) {
			moverAb3 = false;
		}
		if (sunnyDaga.getxSN8() < 1200 && sunnyDaga.getySN8() < 475 && sunnyDaga.getxSN8() > 0
			&& sunnyDaga.getySN8() > 180) {
		moverAb3 = true;
		}

	}

	}

	
}

