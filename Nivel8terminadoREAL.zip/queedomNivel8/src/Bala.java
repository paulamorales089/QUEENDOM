import processing.core.PApplet;

public class Bala {
	int x;
	int y;
	
	public Bala (PApplet app, int x, int y) {
		this.x=x;
		this.y=y;
	}
	public void pintarBala (PApplet app) {
		app.noStroke();
		app.fill(38,11,18);
		app.ellipse(x, y, 25, 6);
		
	}
void moverBala (int xArma, int yArma) {
		x-=5;
	}

}
