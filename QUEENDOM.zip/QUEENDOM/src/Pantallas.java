import processing.core.PApplet;
import processing.core.PImage;

public class Pantallas {

	int x, y;

	private PImage PRINCIPAL;

	public Pantallas(PApplet app, int x, int y) {

		PRINCIPAL = app.loadImage("data/PRINCIPAL.png");

		this.x = x;
		this.y = y;
	}

	public void PintarPrincipal(PApplet app) {
		app.image(PRINCIPAL, x, y);
	}
}
