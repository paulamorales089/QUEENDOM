import processing.core.PApplet;
import processing.core.PImage;

public class Piezas {
int x, y;
	
	public  PImage pieza1;
	public 	PImage pieza2;
	public PImage pieza3;
	public 	PImage pieza4;
	public 	PImage pieza5;

	public Piezas (PApplet app, int x, int y) {
		
		
		pieza1 = app.loadImage("cof1.png");
		pieza2 = app.loadImage("cof2.png");
		pieza3 = app.loadImage("cof3.png");
		pieza4 = app.loadImage("cof4.png");
		pieza5 = app.loadImage("cof5.png");
		
		
		this.x=x;
		this.y=y;
		
	}
	
	public void pintar1 (PApplet app) {
		
		
		
		app.image(pieza1,x,y);
		
	}

	public void pintar2 (PApplet app) {
		
		
		
		app.image(pieza2,x,y);
		
	}

	public void pintar3 (PApplet app) {
		
		
		
		app.image(pieza3,x,y);
		
	}

	public void pintar4 (PApplet app) {
		
		
		
		app.image(pieza4,x,y);
		
	}

	public void pintar5 (PApplet app) {
		
		
		
		app.image(pieza5,x,y);
		
	}
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public void setY(int y) {
		this.y = y;
	}

}
