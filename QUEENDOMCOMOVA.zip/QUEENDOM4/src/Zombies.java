import processing.core.PApplet;
import processing.core.PImage;

public class Zombies {

	// NIVEL 1
	private int xZ;
	private int yZ;

	private PImage zombieFrente;
	private PImage zombieEspalda;
	private PImage zombieDerecha;
	private PImage zombieIzquierda;

	int x, y;
	// VELOCIDAD NIVEL 2
	int speed;
	// ZOMBIES TAMANO GRANDE
	private PImage zombiede;
	// ZOMBIES TAMANO CHIQUITO
	public PImage zombie1, zombie2, zombie3, zombie4;

	public Zombies(PApplet app, int x, int y) {
		// ZOMBIES TAMANO GRANDE
		zombiede = app.loadImage("data/zombiede.png");

		// ZOMBIES TAMANO CHIQUITO
		zombie1 = app.loadImage("data/zombie1.png");
		zombie2 = app.loadImage("data/zombie2.png");
		zombie3 = app.loadImage("data/zombie3.png");
		zombie4 = app.loadImage("data/zombie4.png");
		// ZOMBIES NIVEL1
		zombieFrente = app.loadImage("zombie.png");
		zombieEspalda = app.loadImage("zombieEspalda.png");
		zombieDerecha = app.loadImage("zombieDerecha.png");
		zombieIzquierda = app.loadImage("zombieIzquierda.png");

		this.x = x;
		this.y = y;

		// NIVEL1
		// zombie 1

		this.speed = 2;

		this.xZ = x;
		this.yZ = y;
	
	}

	// METODO PARA ZOMBIES TAMANO GRANDE
	public void pintar(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(zombiede, x, y);
		app.imageMode(app.CORNER);
	}

	public void pintar2(PApplet app) {

		app.imageMode(app.CENTER);
		zombie2.resize(0, 90);
		app.image(zombie2, x, y);
		app.imageMode(app.CORNER);

	}

	public void pintar3(PApplet app) {

		app.imageMode(app.CENTER);
		zombie3.resize(0, 90);
		app.image(zombie3, x, y);
		app.imageMode(app.CORNER);

	}

	// PINTAR LOS ZOMBIES DEL NIVEL 1
	public void pintarZombie1(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(zombieFrente, xZ, yZ);
		app.imageMode(app.CORNER);
	}

	/*8public void pintarZombie2(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(zombieFrente, xZ2, yZ2);
		app.imageMode(app.CORNER);
	}

	public void pintarZombie3(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(zombieFrente, xZ3, yZ3);
		app.imageMode(app.CORNER);
	}
**/
	public void pintarZombie4(PApplet app) {
		app.imageMode(app.CENTER);
		zombieIzquierda.resize(0, 90);
		app.image(zombieIzquierda, xZ, yZ);
		app.imageMode(app.CORNER);
	}

	// MOVER N1
	public void moverZombie1(PApplet app) {

		yZ += speed;

		if (yZ >= 435) {
			// app.image (zombieEspalda,xZ,yZ);
			yZ = 435;
			speed -= 2;

		} else if (yZ <= 200) {
			// app.image(zombieFrente, xZ, yZ);

			yZ = 200;
			speed = 2;
		}

	}

	public void moverZombie2(PApplet app) {

		yZ += speed;

		if (yZ >= 435) {
			yZ = 435;
			speed -= 2;

		} else if (yZ <= 190) {
			yZ = 190;
			speed = 2;
		}
	}

	/**public void moverZombie3(PApplet app) {

		yZ += speed;

		if (yZ >= 435) {
			yZ2 = 435;
			speed -= 2;

		} else if (yZ3 <= 100) {
			yZ3 = 100;
			speed = 2;
		}
	}**/

	public void moverZombie4(PApplet app) {

		xZ += speed;

		if (xZ >= 1058) {
			xZ = 1058;
			speed -= 2;

		} else if (xZ <= 580) {
			xZ = 580;
			speed = 2;
		}
	}

	// mover nivel 2
	public void moverN21(PApplet app) {

		x += speed;

		if (x >= 340) {
			x = 340;
			speed -= 1;

		} else if (x <= 149) {
			x = 149;
			speed = 1;
		}
	}

	public void moverN22(PApplet app) {

		y += speed;

		if (y >= 547) {
			y = 547;
			speed -= 2;

		} else if (y <= 120) {
			y = 120;
			speed = 2;

		}
	}

	public void moverN23(PApplet app) {

		x += speed;

		if (x >= 919) {
			x = 919;
			speed -= 2;

		} else if (x <= 481) {
			x = 481;
			speed = 2;
		}

	}

	// mover nivel 5
	public void mover1() {

		x -= 1;

		if (x < -200) {
			x = 1200;
		}
	}

	public void mover2() {

		x -= 2;

		if (x < -200) {
			x = 1200;
		}
	}

	public void mover3() {

		x -= 4;

		if (x < -200) {
			x = 1200;
		}
	}

	// mover nivel 6
	public void mover4() {

		x -= 1;
	}

	public void mover5() {

		x -= 2;
	}

	public void mover6() {

		x -= 3;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getxZ() {
		return xZ;
	}
	public int getyZ() {
		return yZ;
	}

}
