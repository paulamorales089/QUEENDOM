import processing.core.PApplet;
import processing.core.PImage;

public class Sunny {

	int x, y;
	//SUNNY TAMANO GRANDE
	private PImage sunnynede;
	private PImage sunnyesp;
	private PImage sunnydaga;
	

	//SUNNY TAMANO CHIQUITA 
	public PImage min;
	
	private int xS;
	private int yS;
	private boolean pasar;
	private boolean mostrar;

	//SUNNY CHUIQUITA NIVEL1
	private PImage suniFrente;
	private PImage suniEspalda;
	private PImage suniDerecha;
	private PImage sunnyIzquierda;
	private PImage suniEspadaDer;
	private PImage suniEspadaIzq;


	public Sunny(PApplet app,int x, int y) {
		//SUNNY TAMANO GRANDE
		sunnynede = app.loadImage("data/sunnynede.png");
		sunnyesp = app.loadImage("data/sunnyesp.png");
		sunnydaga = app.loadImage("data/sunnydaga.png");
		
		//SUNNY CHIQUITA NIVEL 2
		
		min = app.loadImage("data/min1.png");
		

		this.x = x;
		this.y = y;
		
		//NIVEL 1
		this.xS = x;
		this.yS = y;

		mostrar = true;
		/*
		 * suniFrente = app.loadImage("sunnyFrente.png"); suniEspalda =
		 * app.loadImage("sunnyEspalda.png");
		 */
		suniDerecha = app.loadImage("sunnyDerecha.png");
		/*
		 * sunnyIzquierda = app.loadImage("sunnyIzquierda.png"); suniEspadaDer =
		 * app.loadImage("suniEspadaDer.png"); suniEspadaIzq =
		 * app.loadImage("suniEspadaIzq.png");
		 */
	}
     //METODOS PARA SUNNY TAMANO GRANDE
     	public void pintar(PApplet app) {
		app.imageMode (app.CENTER);
		app.image(sunnynede, x, y);
		app.imageMode (app.CORNER);
		
		
	}
     	
     	public void pintar1(PApplet app) {
     		//METODOS PARA SUNNY TAMANO CHIQUITA NIVEL 2
    		min.resize(0, 80);
    		app.imageMode(app.CENTER);
    		app.image(min,x,y);
    		app.imageMode(app.CORNER);
     		
     	}
     	
     	
	
	public void pintarEspada(PApplet app) {
		app.imageMode (app.CENTER);
		app.image(sunnyesp, x, y);
		app.imageMode (app.CORNER);
	}
	public void pintarDaga(PApplet app) {
		app.imageMode (app.CENTER);
		app.image(sunnydaga, x, y);
		app.imageMode (app.CORNER);
	}
	
	public void pintarFrenteSunny(PApplet app) {
		app.imageMode(app.CENTER);
		suniDerecha.resize(0, 75);
		app.image(suniDerecha, xS, yS);
		app.imageMode(app.CORNER);
	}
	public void moverArriba() {

		y -= 20;
	}

	public void moverAbajo() {

		y += 20;
	}
	
	public void moverAdelante() {

		x += 20;
	}
	
	public void moverAtras() {

		x -= 20;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	public void moverArribaN1() {

		yS -= 30;
	}

	public void moverAbajoN1() {

		yS += 30;
	}

	public void moverAdelanteN1() {

		xS += 30;
	}

	public void moverAtrasN1() {

		xS -= 30;
	}

	public int getxS() {
		return xS;
	}

	public int getyS() {
		return yS;
	}

}
