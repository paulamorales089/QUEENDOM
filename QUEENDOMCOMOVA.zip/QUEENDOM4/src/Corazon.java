import processing.core.PApplet;
import processing.core.PImage;

public class Corazon {

	private int xC, xC2, xC3, xC4,xC5;
	private int yC, yC2, yC3, yC4,yC5;
	private PImage corazon;
	
	public Corazon(PApplet app) {
		
		this.xC=1041;
		this.yC=350;
		
		this.xC2=880;
		this.yC2=226;
		
		this.xC3=753;
		this.yC3=230;
		
		this.xC4=753;
		this.yC4=290;
		
		this.xC5=753;
		this.yC5=350;
		
		corazon = app.loadImage("CORA.png");
		
	}

	public void pintarCorazon1 (PApplet app) {
		corazon.resize(0, 60);
		
		app.image(corazon,xC,yC);
	}
	public void pintarCorazon2 (PApplet app) {
		corazon.resize(0, 60);
	
		app.image(corazon,xC2,yC2);
	}
	public void pintarCorazon3 (PApplet app) {
		corazon.resize(0, 60);
		app.image(corazon,xC3,yC3);
	}
	public void pintarCorazon4 (PApplet app) {
		corazon.resize(0, 60);
		app.image(corazon,xC4,yC4);
	}
	public void pintarCorazon5 (PApplet app) {
		corazon.resize(0, 60);
		app.image(corazon,xC5,yC5);
	}
	
	
	//get corazon1
	public int getxC() {
		return xC;
	}
	public int getyC() {
		return yC;
	}
	// get corazon2
	public int getxC2() {
		return xC2;
	}
	public int getyC2() {
		return yC2;
	}
	//get corazon3 
	public int getxC3() {
		return xC3;
	}
	public int getyC3() {
		return yC3;
	}
	//get corazon 4
	public int getxC4() {
		return xC4;
	}
	public int getyC4() {
		return yC4;
	}
	//get corazon 5
	public int getxC5() {
		return xC5;
	}
	public int getyC5() {
		return yC5;
	}
	
	//set corazon
	public void setxC(int xC) {
		this.xC = xC;
	}
	public void setyC(int yC) {
		this.yC = yC;
	}
	public void setxC2(int xC2) {
		this.xC2 = xC2;
	}
	public void setyC2(int yC2) {
		this.yC2 = yC2;
	}
	public void setxC3(int xC3) {
		this.xC3 = xC3;
	}
	public void setyC3(int yC3) {
		this.yC3 = yC3;
	}
	public void setxC4(int xC4) {
		this.xC4 = xC4;
	}
	public void setyC4(int yC4) {
		this.yC4 = yC4;
	}
	public void setxC5(int xC5) {
		this.xC5 = xC5;
	}
	public void setyC5(int yC5) {
		this.yC5 = yC5;
	}
	
public void setXY1(int xC,int yC) {
	this.xC = xC;
	this.yC = yC;
	}
public void setXY2(int xC2, int yC2) {
	this.xC2 = xC2;
	this.yC2 = yC2;
	}
public void setXY3(int xC3, int yC3) {
	this.xC3 = xC3;
	this.yC3 = yC3;
}
public void setXY4(int xC4, int yC4) {
	this.xC4 = xC4;
	this.yC4 = yC4;
}
public void setXY5(int xC5,int yC5) {
	this.xC5 = xC5;
	this.yC5 = yC5;
}
}
