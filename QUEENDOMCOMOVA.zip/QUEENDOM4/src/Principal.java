import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;
import processing.event.MouseEvent;

public class Principal extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Principal");
	}

	@Override
	public void settings() {
		size(1200, 700);
	}

	int estado = 0; // PANTALLAS
	// NIVEL 1
	int[][] casillas;

	// FONDO
	PImage fondo;

	// X y Y DE ZOMBIES
	int xZ, xZ2;
	int yZ, yZ2;
	Sunny sunnyP;
	Zombies zombieN11, zombieN12, zombieN13, zombieN14;
	Corazon corazonZombie;

	// SUNNY
	int sunnyX;
	int sunnyY;

	// CORAZON
	int corazonX1;
	int corazonY1;

	// DESAPARECER CORAZONES
	boolean mostrarCorazon1;
	boolean mostrarCorazon2;
	boolean mostrarCorazon3;
	boolean mostrarCorazon4;
	boolean mostrarCorazon5;

	// SUMA CONTADOR CORAZONES
	int contadorN1;
	int contador2;
	int contador3;
	int contador4;
	int contador5;
	int contador6;
	int resultado;

	// BOOLEAN DE MOVIMEINTO DE SUNNY
	boolean moverAr1N1 = true;
	boolean moverAb1N1 = true;

	boolean moverAr2N1 = true;
	boolean moverAb2N1 = true;

	boolean moverAd1N1 = true;
	boolean moverAt1N1 = true;

	boolean moverAr4N1 = true;
	boolean moverAb4N1 = true;
	// FIN NIVEL1

	// NIVEL 2
	PImage fondo2;

	PImage arma1;
	PImage arma2;

	Sunny sunnyN2;
	Zombies zombieN1;
	Zombies zombieN2;
	Zombies zombieN3;

	// movimiento sunny
	boolean moverArN1 = true;
	boolean moverAbN1 = true;

	// zombie1
	boolean moverArN2 = true;
	boolean moverAbN2 = true;
	// zombie2
	boolean moverAd1 = true;
	boolean moverAt1 = true;
	// zombie3
	boolean moverAr4 = true;
	boolean moverAb4 = true;

	boolean mostrarN1 = true;
	boolean mostrarN2 = true;

	int px, py;

	int x, y;
	int x2, y2;
	int x3, y3;

	int Rx1, Ry1;
	int Rx2, Ry2;

	int LP, LP2;

	// FIN VARIABLES NIVEL 2

	// NIVEL 3
	// variables
	int velocidad = 3;
	PImage NIVEL3;
	ArrayList<Personajes> personajes;

	Personajes elementos;
	int contador1;
	// FIN VARIABLES NIVEL 3
	
	//VARIABLES NIVEL 4
	int click=1;
	boolean bc;
	PImage NIVEL4, perdio;
	
	ArrayList<Recolectores> listaColor;
	ArrayList<Enemigo> listaCabeza;
	
	BolitaNegra capturador;
	Recolectores elementosN4;
	int contador1N4;
	// FIN VARIABLES NIVEL 4
	

	// NIVELES 5 Y 6
	// Nivel 5
	Sunny sunny;
	Sunny sunnyespada;
	Sunny sunnydaga;

	// nivel 5
	// carril1
	Zombies zombie1;
	Zombies zombie2;

	// carril2
	Zombies zombie3;

	// carril3
	Zombies zombie4;
	Zombies zombie5;

	// nivel6
	// carril1
	Zombies zombie1A;
	Zombies zombie2A;

	// carril2
	Zombies zombie3A;

	// carril3
	Zombies zombie4A;
	Zombies zombie5A;

	// VARIABLES NIVELES 5 Y 6
	int mostrar;
	boolean mostrar1 = true;
	boolean mostrar2 = true;
	boolean mostrar3 = true;
	boolean mostrar4 = true;
	boolean mostrar5 = true;
	int espada = 0;
	int daga = 0;
	boolean moverAr1 = true;
	boolean moverAb1 = true;
	boolean moverAr2 = true;
	boolean moverAb2 = true;
	boolean moverAr3 = true;
	boolean moverAb3 = true;
	boolean perder = true;
	// FIN DE LAS VARIABLES DE LOS NIVELES 5 Y 6

	// NIVEL 7
	PImage fondo7;

	PImage personaje;
	PImage cofre;
	PImage corazon;

	Cuadros cuadro1;
	Cuadros cuadro2;
	Cuadros cuadro3;
	Cuadros cuadro4;
	Cuadros cuadro5;

	Piezas p1;
	Piezas p2;
	Piezas p3;
	Piezas p4;
	Piezas p5;

	Piezas pi1;
	Piezas pi2;
	Piezas pi3;
	Piezas pi4;
	Piezas pi5;

	int puntos;

	// FIN DE LAS VARIABLES DE LOS NIVELES 7

	// IMAGENES DE FONDO
	private PImage PRINCIPAL;
	private PImage NIVEL5;
	private PImage NIVEL6;
	private PImage PERDIO;
	private PImage GANO;

	@Override
	public void setup() {

		// FONDOS GENERALES
		PRINCIPAL = loadImage("data/PRINCIPAL.png");
		PERDIO = loadImage("data/PERDIO.png");
		GANO = loadImage("data/GANO.png");

		// llamar nivel1
		// FONDO
		fondo = loadImage("NIVEL 1.png");

		// PERSONAJES
		sunnyP = new Sunny(this, 74, 490);
		zombieN11 = new Zombies(this, 140, 250);
		zombieN12 = new Zombies(this, 285, 250);
		zombieN13 = new Zombies(this, 527, 250);
		zombieN14 = new Zombies(this, 1058, 483);

		// CORAZONES
		corazonZombie = new Corazon(this);

		// gets corazon y sunny
		sunnyX = sunnyP.getxS();
		sunnyY = sunnyP.getyS();
		corazonX1 = corazonZombie.getxC();
		corazonY1 = corazonZombie.getyC();

		// DESAPARECER CORAZONES
		mostrarCorazon1 = true;
		mostrarCorazon2 = true;
		mostrarCorazon3 = true;
		mostrarCorazon4 = true;
		mostrarCorazon5 = true;

		// SUMA CONTADOR CORAZONES
		contadorN1 = 0;
		contador2 = 0;
		contador3 = 0;
		contador4 = 0;
		contador5 = 0;
		contador6 = 0;
		// FIN LLAMAR NIVEL 1

		// LLAMAR NIVEL 2
		// images level 2
		fondo2 = loadImage("NIVEL 2.png");

		arma2 = loadImage("daga.png");
		arma1 = loadImage("espada.png");

		px = 30;
		py = 300;

		x = 481;
		y = 490;

		x2 = 970;
		y2 = 130;

		x3 = 122;
		y3 = 213;

		Rx1 = 651;
		Ry1 = 13;

		Rx2 = 754;
		Ry2 = 13;

		sunnyN2 = new Sunny(this, px, py);

		zombieN3 = new Zombies(this, x3, y3);
		zombieN2 = new Zombies(this, x2, y2);
		zombieN1 = new Zombies(this, x, y);

		estado = 0;

		LP = 0;
		LP2 = 0;
		// FIN LLAMAR NIVEL 2

		// LLAMAR NIVEL 3
		// fondo

		NIVEL3 = loadImage("NIVEL 3.png");

		personajes = new ArrayList<Personajes>();

		for (int i = 0; i < 13; i++) { // Number of times that the colored balls must be created and the making of the
										// balls.
			int tempXpos = (int) random(1200);
			int tempYpos = (int) random(70, 500);
			int tempXspeed = (int) random(5, 7);
			personajes.add(new Personajes(this, tempXpos, tempYpos, tempXspeed));

		}
		// LLAMAR NIVEL 3
		
		//LLAMAR NIVEL 4
		estado = 1;
		bc = true;
		
		listaColor = new ArrayList<Recolectores>();
		listaCabeza = new ArrayList<Enemigo>();
				
		capturador = new BolitaNegra();
		
		NIVEL4 = loadImage("NIVEL 4.png");
		perdio = loadImage("PERDIÓ.png");
		
		for (int i = 0; i <10; i++) { 
			int xTemp = (int) random (50,950);
			int yTemp = (int) random (200);
			listaColor.add(new Recolectores(this, xTemp, yTemp));
		}
		
		for (int i = 0; i < 3; i++) { 
			int xTemp = (int) random (1100);
			int yTemp = (int) random (200);
			listaCabeza.add(new Enemigo(this, xTemp, yTemp));
		}
		//FIN LLAMAR 4

		// LLAMAR CLASES EN LOS NIVELES 5 Y 6

		// FONDOSNIVELES 5 Y 6
		NIVEL5 = loadImage("data/NIVEL 5.png");
		NIVEL6 = loadImage("data/NIVEL 6.png");

		// Sunny
		// nivel 5
		sunny = new Sunny(this, 10, 300);
		System.out.println(sunny);

		// nivel 6
		sunnyespada = new Sunny(this, 90, 300);
		System.out.println(sunnyespada);

		sunnydaga = new Sunny(this, 90, 300);
		System.out.println(sunnydaga);

		// Zombies NIVEL 5
		zombie1 = new Zombies(this, 1156, 170);
		System.out.println(zombie1);
		zombie2 = new Zombies(this, 1156, 170);
		System.out.println(zombie2);

		zombie3 = new Zombies(this, 1156, 329);
		System.out.println(zombie3);

		zombie4 = new Zombies(this, 1156, 470);
		System.out.println(zombie4);
		zombie5 = new Zombies(this, 1156, 470);
		System.out.println(zombie5);

		// Zombies NIVEL 6
		zombie1A = new Zombies(this, 1156, 170);
		System.out.println(zombie1A);
		zombie2A = new Zombies(this, 1156, 170);
		System.out.println(zombie2A);

		zombie3A = new Zombies(this, 1156, 329);
		System.out.println(zombie3A);

		zombie4A = new Zombies(this, 1156, 470);
		System.out.println(zombie4A);
		zombie5A = new Zombies(this, 1156, 470);
		System.out.println(zombie5A);
		// FIN DE LLAMAR A LOS NIVELES 5 Y 6

		// LLAMAR CLASES NIVEL 7
		fondo7 = loadImage("NIVEL 7.png");

		corazon = loadImage("corazon.png");

		personaje = loadImage("min2.png");
		cofre = loadImage("cofre.png");
		corazon = loadImage("corazon.png");

		cuadro1 = new Cuadros(720, 147, 124, 374);
		cuadro2 = new Cuadros(844, 147, 124, 125);
		cuadro3 = new Cuadros(968, 147, 124, 125);
		cuadro4 = new Cuadros(844, 271, 248, 125);
		cuadro5 = new Cuadros(844, 396, 248, 125);

		p1 = new Piezas(this, 422, 91);
		p2 = new Piezas(this, 555, 91);
		p3 = new Piezas(this, 555, 239);
		p4 = new Piezas(this, 555, 394);
		p5 = new Piezas(this, 133, 91);

		pi1 = null;
		pi2 = null;
		pi3 = null;
		pi4 = null;
		pi5 = null;

		puntos = 0;
		// FIN DE LLAMAR EL NIVEL 7
	}

	@Override
	public void draw() {
		background(255);

		// Pantalla principal
		if (estado == 0) {
			image(PRINCIPAL, 0, 0);
		}

		// Nivel 1 //Paula
		if (estado == 1) {

			// fondo
			image(fondo, 0, 0);
			// matriz
			for (int i = 0; i < 2400; i += 30) {
				for (int j = 39 * 2; j < 564; j += 30) {
					noFill();
					square(i, j, 30);
				}
			}

			sunnyP.pintarFrenteSunny(this);

			// ZOMBIES ZOMBIES ZOMBIES
			zombieN11.pintarZombie1(this);
			zombieN11.moverZombie1(this);

			zombieN12.pintarZombie1(this);
			zombieN12.moverZombie2(this);

			zombieN13.pintarZombie1(this);
			zombieN13.moverZombie1(this);

			zombieN14.pintarZombie4(this);
			zombieN14.moverZombie4(this);

			// CONTADOR CORAZONES (ESCRITO)
			fill(0);
			textSize(20);
			resultado = contador6 + contadorN1 + contador2 + contador3 + contador4 + contador5;
			text(resultado, 615, 47);
			text("/5", 626, 47);

			// DESAPARECER CORAZONES
			if (mostrarCorazon1 == true) {
				corazonZombie.pintarCorazon1(this);
			}
			if (mostrarCorazon2 == true) {
				corazonZombie.pintarCorazon2(this);
			}
			if (mostrarCorazon3 == true) {
				corazonZombie.pintarCorazon3(this);
			}
			if (mostrarCorazon4 == true) {
				corazonZombie.pintarCorazon4(this);
			}
			if (mostrarCorazon5 == true) {
				corazonZombie.pintarCorazon5(this);
			}

			// CONTADOR DE CORAZONES
			if (mostrarCorazon1 == false) {
				contadorN1 = 1;

				if (contadorN1 > 1) {
					contadorN1 = 1;
				}
			}
			if (mostrarCorazon2 == false) {
				contador2 = 1;
				if (contador2 > 1) {
					contador2 = 1;
				}
			}
			if (mostrarCorazon3 == false) {
				contador3 = 1;

				if (contador3 > 1) {
					contador3 = 1;
				}
			}
			if (mostrarCorazon4 == false) {
				contador4 = 1;

				if (contador4 > 1) {
					contador4 = 1;
				}
			}
			if (mostrarCorazon5 == false) {
				contador5 = 1;
				if (contador5 > 1) {
					contador5 = 1;
				}
			}

			// SE PUEDE PASAR AL NIVEL 2

			if (resultado == 5) {
				if (sunnyP.getxS() > 1200) {
					estado = 2;
				}
			}
		}

		// Nivel 2 //Laura
		if (estado == 2) {

			// scenario level 2
			imageMode(CENTER);
			image(fondo2, 600, 350);
			imageMode(CORNER);

			sunnyN2.pintar1(this);

			zombieN3.pintar3(this);
			zombieN3.moverN21(this);

			zombieN2.pintar2(this);
			zombieN2.moverN22(this);

			zombieN1.pintar3(this);
			zombieN1.moverN23(this);

			if (mostrarN1 == true) {

				noStroke();
				fill(96, 159, 144);
				rect(Rx1, Ry1, 41, 45);
				image(arma1, 130, 126);

			}

			if (mostrarN2 == true) {

				noStroke();
				fill(96, 159, 144);
				rect(Rx2, Ry2, 41, 45);
				image(arma2, 505, 289);
			}

			if (mostrarN1 == false) {

				noStroke();
				fill(96, 159, 144);
				rect(Rx2 + 41, Ry2, 42, 42);
				LP = 2;

			}

			if (mostrarN2 == false) {

				noStroke();
				fill(96, 159, 144);
				rect(Rx1 + 41, Ry1, 42, 42);
				LP2 = 2;

			}

			if (LP == 2 && LP2 == 2) {

				if (sunnyN2.getX() < 1200 && sunnyN2.getY() < 562 && sunnyN2.getX() > 1169 && sunnyN2.getY() > 110) {

					estado = 3;
				}

			}

		//	System.out.println(LP);
		//	System.out.println(LP2);

		}

		// Nivel 3 //Majo
		if (estado == 3) {

			// Fondo

			background(255);
			imageMode(CENTER);
			image(NIVEL3, 600, 350, 1300, 700);
			imageMode(CORNER);

			// personajes
			for (int i = 0; i < personajes.size(); i++) {

				personajes.get(i).PintarPato(this);
				personajes.get(i).mover();
			}
			if (contador1 == 13) {
				estado = 4;
			}

			fill(0);
			textSize(20);
			text(contador1, 633, 47);

		}
		// Nivel 4 //Majo
		if (estado == 4) {

			background(255);
			imageMode(CENTER);
			image(fondo,600,350,1300,700);
			imageMode(CORNER);
				
			if (click==1) { //Start Button
				rectMode(CENTER);
				strokeWeight(3);
				fill(255);
				rect(width/2,height/2,150,60);
				fill(0);
				textSize(32);
				textAlign(CENTER);
				text("START",width/2,height/2+10);
			}
			
			if (estado==10) { //perdiste
				
				imageMode(CENTER);
				image(perdio,600,350,1300,700);
				imageMode(CORNER);
				 bc = false;
				
			}
			
			if (bc == true) {
			capturador.pintar(this); //Bola negra 
			}
				
			for (int i = 0; i < listaColor.size(); i++) { 
				Recolectores actual = listaColor.get(i);
				actual.PintarCorazon(this);
				
				
				if (click==2) { 
					
					actual.mover();
					
				} 
				
				if (dist(capturador.getX(),capturador.getY(),actual.getX(),actual.getY())<70) {
					capturador.agregarBolita(listaColor.get(i));
					listaColor.remove(i);
					
				} else if (estado == 10) {
					
					listaColor.remove(i);
					
				}
				
			}
			
			
			
			for (int i = 0; i < listaCabeza.size(); i++) {
				
				Enemigo actual = listaCabeza.get(i);
				actual.PintarCabeza(this);
				
				if (click==2) { 
					
					actual.mover();
					
				} 
				
				if (dist(capturador.getX(),capturador.getY(),actual.getX(),actual.getY())< 100) {
					
					capturador.agregarCabeza(listaCabeza.get(i));
					listaCabeza.remove(i);
					
					estado = 5 ;
					
				}  else if (estado == 10) {
					
					listaCabeza.remove(i);
					
				}
				
			}

		}
		// Nivel 5 //Lina
		if (estado == 5) {

			// carretera nivel 5
			image(NIVEL5, 0, 0);
			// pintar Sunny

			sunny.pintar(this);

			// pintar zombies

			zombie1.pintar(this);
			zombie2.pintar(this);
			zombie3.pintar(this);
			zombie4.pintar(this);
			zombie5.pintar(this);

			zombie1.mover3();
			zombie2.mover1();
			zombie3.mover2();
			zombie4.mover3();
			zombie5.mover1();

			// perder repetir el juego

			if (dist(sunny.getX(), sunny.getY(), zombie1.getX(), zombie1.getY()) < 80) {
				estado = 10;
			}
			if (dist(sunny.getX(), sunny.getY(), zombie2.getX(), zombie2.getY()) < 80) {
				estado = 10;
			}
			if (dist(sunny.getX(), sunny.getY(), zombie3.getX(), zombie3.getY()) < 80) {
				estado = 10;
			}
			if (dist(sunny.getX(), sunny.getY(), zombie4.getX(), zombie4.getY()) < 80) {
				estado = 10;
			}
			if (dist(sunny.getX(), sunny.getY(), zombie5.getX(), zombie5.getY()) < 80) {
				estado = 10;

			}

			// condicion si gana

			// ganar pasar nivel 6
			if (sunny.getX() > 1200) {
				estado = 6;

			}

		}
		// Nivel 6 //Lina
		if (estado == 6) {
			// carretera nivel 6

			image(NIVEL6, 0, 0);

			if (mostrar == 0) {
				sunnyespada.pintarEspada(this);
				noFill();
				rect(624, 8, 60, 50);
			}

			if (mostrar == 1) {
				sunnyespada.pintarDaga(this);
				noFill();
				rect(724, 8, 60, 50);
			}
			// pintar zombies
			if (mostrar1 == true) {
				zombie1A.pintar(this);
				zombie1A.mover4();
			}
			if (mostrar2 == true) {
			 	zombie2A.pintar(this);
			    zombie2A.mover4();
			}
			if (mostrar3 == true) {
				zombie3A.pintar(this);
				zombie3A.mover6();
			}
			if (mostrar4 == true) {
				zombie4A.pintar(this);
				zombie4A.mover5();
			}
			if (mostrar5 == true) {
				zombie5A.pintar(this);
				zombie5A.mover4();
			}
			
			
			if (espada == 0) {
				
				if (mostrar1==true){
			
			if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie1A.getX(), zombie1A.getY()) < 80) {
				estado = 10;
			
			}
				}

				if (mostrar2==true){
			if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie2A.getX(), zombie2A.getY()) < 80) {
				estado = 10;
	
			}
				}
				
				if (mostrar3==true){
			if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie3A.getX(), zombie3A.getY()) < 80) {
				estado = 10;

			}
				}
				if (mostrar4==true){
			if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie4A.getX(), zombie4A.getY()) < 80) {
				estado = 10;
			
			}
			}
				if (mostrar5==true){
			if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie5A.getX(), zombie5A.getY()) < 80) {
				estado = 10;
			}
			}
			}
			

				// ganar pasar nivel 7
				if (sunnyespada.getX() > 1200) {
					estado = 7;// nivel7
				}
			
	         	if (daga == 0) {

	         		if (mostrar1==true){
				if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie1A.getX(), zombie1A.getY()) < 80) {
					estado = 10;
				//	perder=false;
				}
				}
	         		if (mostrar2==true){
				if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie2A.getX(), zombie2A.getY()) < 80) {
					estado = 10;
				//	perder=false;
				}
				}
	         		if (mostrar3==true){
				if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie3A.getX(), zombie3A.getY()) < 80) {
					estado = 10;
				//	perder=false;
				}
				}
	         		if (mostrar4==true){
				if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie4A.getX(), zombie4A.getY()) < 80) {
					estado = 10;
				//	perder=false;
				}
				}
	         		if (mostrar5==true){
				if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie5A.getX(), zombie5A.getY()) < 80) {
					estado = 10;
				//	perder=false;
				}
				}
	         	}
				
				// ganar pasar nivel 7
				if (sunnydaga.getX() > 1200) {
					estado = 7;// nivel7
				}
			}
		
		// Nivel 7 //Laura
		if (estado == 7) {

			image(fondo7, 0, 0);

			cuadro1.pintar(this);
			cuadro2.pintar(this);
			cuadro3.pintar(this);
			cuadro4.pintar(this);
			cuadro5.pintar(this);

			personaje.resize(0, 400);
			imageMode(CENTER);
			image(personaje, 270, 400);
			imageMode(CORNER);

			p1.pintar1(this);
			p2.pintar2(this);
			p3.pintar3(this);
			p4.pintar4(this);
			p5.pintar5(this);

			// ganar el nivel 7 y pasar al 8
			if (puntos == 5) {
				corazon.resize(0, 100);
				image(corazon, 250, 150);
			}

		}
		// Nivel 8 //Paula
		if (estado == 8) {

			// condicion si pierde
			/**
			 * if (condicion) { estado = 10;
			 * 
			 * }
			 **/

			// condicion si gana
			/**
			 * if (condicion) { estado = 9;
			 * 
			 * }
			 **/

		}
		// Nivel 9 //Paula
		if (estado == 9) {

			// condicion si pierde
			/**
			 * if (condicion) { estado = 10;
			 * 
			 * }
			 **/

			// condicion si gana
			/**
			 * if (condicion) { estado = 11;
			 * 
			 * }
			 **/
		}
		// PIERDE el juego
		if (estado == 10) {
			image(PERDIO, 0, 0);
		}

		// GANA el juego
		if (estado == 11) {
			image(GANO, 0, 0);
		}
		 System.out.println(mouseX + "," + mouseY);
	}
	

	@Override
	public void mousePressed() {

		// MOUSEPRESSED GENERAL
		// Boton de jugar
		if (dist(mouseX, mouseY, 597, 556) < 20) {
			estado = 1;
		}
		// perder boton reintentar
		if (estado == 10) {
			if (dist(mouseX, mouseY, 618, 475) < 30) {
				estado = 0;
			}
		}
		// FIN DEL MOUSEPRESSED GENERAL

		// MOUSEPRESSED NIVEL 3
		if (estado == 3) {
			for (int i = 0; i < personajes.size(); i++) {

				if (dist(mouseX, mouseY, personajes.get(i).getposX(), personajes.get(i).getposY()) < 65) {

					personajes.remove(i);
					contador1++;
				}
			}

		}
		// FIN DEL MOUSEPRESSED DEL NIVEL 3
		
		//  MOUSEPRESSED DEL NIVEL 4
        if (estado==4) {
        	if (mouseX > width/2 - 60 && mouseX < width/2 + 60 && mouseY > height/2 - 60 && mouseY < height/2+60) {
    			click = 2; 
    		}
    		
    		if (mouseX > 400 && mouseX < 600 && mouseY > 500 && mouseY < 650) {
    			
    			click = 2; //Makes restart button work. 

    		}
    		// FIN DEL MOUSEPRESSED DEL NIVEL 4
        }
		// MOUSEPRESSED NIVEL 6
		// seleccion de armas
		// espada
		if (estado == 6) {
			if (dist(mouseX, mouseY, 651, 38) < 20) {
				// pintar Sunny con espada
				if (espada == 0) {
					mostrar = 0;
				}
			}
			// daga

			if (dist(mouseX, mouseY, 751, 40) < 20) {
				// pintar Sunny con dagas
				if (daga == 0) {
					mostrar = 1;
				}
			}

			//Matar a los zombies
			
			if (mostrar==0 ) {
				// espada
				
				if (dist(mouseX, mouseY, zombie1A.getX(), zombie1A.getY()) < 100) {
					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie1A.getX(), zombie1A.getY()) < 600) {
						mostrar1 = false;
						perder=false;
							
					}
				}
				if (dist(mouseX, mouseY, zombie2A.getX(), zombie2A.getY()) < 100) {
					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie2A.getX(), zombie2A.getY()) < 600) {
						mostrar2 = false;
						perder=false;
					
					}
				}
				if (dist(mouseX, mouseY, zombie3A.getX(), zombie3A.getY()) < 100) {
					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie3A.getX(), zombie3A.getY()) < 600) {
						mostrar3 = false;
						perder=false;
					
					}
				}
				
				if (dist(mouseX, mouseY, zombie4A.getX(), zombie4A.getY()) < 100) {
					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie4A.getX(), zombie4A.getY()) < 600) {
						mostrar4 = false;
					
					}
				}
				
				if (dist(mouseX, mouseY, zombie5A.getX(), zombie5A.getY()) < 100) {
					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie5A.getX(), zombie5A.getY()) < 600) {
						mostrar5 = false;
						perder=false;
					}
				}
			}

			if (mostrar==1) {
				
				// daga
				if (dist(mouseX, mouseY, zombie1A.getX(), zombie1A.getY()) < 100) {
					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie1A.getX(), zombie1A.getY()) < 300) {
						mostrar1 = false;
						perder=false;
					}
				}

				if (dist(mouseX, mouseY, zombie2A.getX(), zombie2A.getY()) < 100) {

					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie2A.getX(), zombie2A.getY()) < 300) {
						mostrar2 = false;
						perder=false;
					}
				}
				if (dist(mouseX, mouseY, zombie3A.getX(), zombie3A.getY()) < 100) {
					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie3A.getX(), zombie3A.getY()) < 300) {
						mostrar3 = false;
						perder=false;
					}
				}

				if (dist(mouseX, mouseY, zombie4A.getX(), zombie4A.getY()) < 100) {
					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie4A.getX(), zombie4A.getY()) < 300) {
						mostrar4 = false;
						perder=false;
					}
				}
				if (dist(mouseX, mouseY, zombie5A.getX(), zombie5A.getY()) < 100) {
					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie5A.getX(), zombie5A.getY()) < 300) {
						mostrar5 = false;
						perder=false;
					}
				}
			}
		}		// FIN DEL MOUSEPRESSED DE LOS NIVELES 5 Y 6

		// MOUSEPRESSED NIVEL 7
		if (estado == 7) {
			if (dist(mouseX, mouseY, p1.getX(), p1.getY()) < 40) {

				pi1 = p1;
			}

			if (dist(mouseX, mouseY, p2.getX(), p2.getY()) < 64) {

				pi2 = p2;
			}

			if (dist(mouseX, mouseY, p3.getX(), p3.getY()) < 40) {

				pi3 = p3;
			}

			if (dist(mouseX, mouseY, p4.getX(), p4.getY()) < 40) {

				pi4 = p4;
			}

			if (dist(mouseX, mouseY, p5.getX(), p5.getY()) < 40) {

				pi5 = p5;
			}
			// PASAR NIVEL 8
			if ((dist(mouseX, mouseY, 250, 150) < 60) && puntos == 5) {

				estado = 8;

			}
		}

		// FIN DEL MOUSEPRESSED DEL NIVEL 7

		// MOUSEPRESSED NIVEL 8
		if (estado == 8) {

		}
		// FIN DEL MOUSEPRESSED DEL NIVEL 8

		// MOUSEPRESSED NIVEL 9
		if (estado == 9) {

		}
		// FIN DEL MOUSEPRESSED DEL NIVEL 9
	}

	@Override
	public void keyPressed() {
		// KEYPRESSED DEL NIVEL 1
		if (estado == 1) {
			// MOVER PERSONAJE
			if (moverAr1N1 == true) {
				if (key == 'w' || key == 'W') {
					sunnyP.moverArribaN1();
				}
			}
			if (moverAb1N1 == true) {
				if (key == 's' || key == 'S') {
					sunnyP.moverAbajoN1();
				}
			}

			if (moverAd1N1 == true) {
				if (key == 'd' || key == 'D') {
					sunnyP.moverAdelanteN1();
				}
			}

			if (moverAt1N1 == true) {
				if (key == 'a' || key == 'A') {
					sunnyP.moverAtrasN1();
				}
			}

			// LIMITACIONES DE MOVIMIENTO
			if (sunnyP.getxS() < 1200 && sunnyP.getyS() < 150 && sunnyP.getxS() > 0 && sunnyP.getyS() > 0) {
				moverAr1N1 = false;
			}
			if (sunnyP.getxS() < 1200 && sunnyP.getyS() < 500 && sunnyP.getxS() > 0 && sunnyP.getyS() > 180) {
				moverAr1N1 = true;
			}

			// LIMITACIONES MOVIMIENTOS PARA MOVERSE HACIA ABAJO
			if (sunnyP.getxS() < 1200 && sunnyP.getyS() > 400 && sunnyP.getxS() > 0 && sunnyP.getyS() > 0) {
				moverAb1N1 = false;
			}
			if (sunnyP.getxS() < 1200 && sunnyP.getyS() < 475 && sunnyP.getxS() > 0 && sunnyP.getyS() > 180) {
				moverAb1N1 = true;

				// LIMITACIONES MOVIMIENTOS ARBUSTO 1 (HORIZONTALES)
			}
			if (sunnyP.getxS() < 457 && sunnyP.getyS() > 180 && sunnyP.getxS() > 330 && sunnyP.getyS() < 430) {
				moverAr1N1 = false;
			}
			if (sunnyP.getxS() < 457 && sunnyP.getyS() < 230 && sunnyP.getxS() > 330 && sunnyP.getyS() > 130) {
				moverAr1N1 = true;
				moverAb1N1 = true;
			}
			if (sunnyP.getxS() < 457 && sunnyP.getyS() > 180 && sunnyP.getxS() > 330 && sunnyP.getyS() < 300) {
				moverAb1N1 = false;
			}

			// limitacion movimientos arbusto 1 (partes verticales)
			// ahora lo hago
			if (sunnyP.getxS() < 330 && sunnyP.getyS() > 407 && sunnyP.getxS() > 330 && sunnyP.getyS() < 230) {
				moverAd1N1 = false;
			}

			// LIMITACIONES MOVIMIENTOS ARBUSTO 2 (HORIZONTALES)
			if (sunnyP.getxS() < 725 && sunnyP.getyS() > 180 && sunnyP.getxS() > 600 && sunnyP.getyS() < 430) {
				moverAr1N1 = false;
			}
			if (sunnyP.getxS() < 725 && sunnyP.getyS() < 230 && sunnyP.getxS() > 600 && sunnyP.getyS() > 130) {
				moverAr1N1 = true;
				moverAb1N1 = true;
			}
			if (sunnyP.getxS() < 725 && sunnyP.getyS() > 180 && sunnyP.getxS() > 600 && sunnyP.getyS() < 300) {
				moverAb1N1 = false;
			}
			// limitacion movimientos arbusto 2 (partes verticales)
			// ahora lo hago

			// LIMITACIONES MOVIMIENTOS ARBUSTO 3 (HORIZONTALES)
			if (sunnyP.getxS() < 1030 && sunnyP.getyS() > 260 && sunnyP.getxS() > 840 && sunnyP.getyS() < 430) {
				moverAr1N1 = false;
			}
			if (sunnyP.getxS() < 1030 && sunnyP.getyS() < 230 && sunnyP.getxS() > 840 && sunnyP.getyS() > 130) {
				moverAr1N1 = true;
				moverAb1N1 = true;
			}
			if (sunnyP.getxS() < 1030 && sunnyP.getyS() > 230 && sunnyP.getxS() > 840 && sunnyP.getyS() < 300) {
				moverAb1N1 = false;
			}

			// LIMITACIONES MOVIMIENTOS ARBUSTO 4 (HORIZONTALES)
			if (sunnyP.getxS() < 1090 && sunnyP.getyS() > 347 && sunnyP.getxS() > 967 && sunnyP.getyS() < 230) {
				moverAr1N1 = false;
			}

			// DESAPARECER CORAZONES SI ESTAS CERCA
			if (dist(sunnyP.getxS(), sunnyP.getyS(), 1060, 370) < 30) {
				mostrarCorazon1 = false;
			}
			if (dist(sunnyP.getxS(), sunnyP.getyS(), 900, 246) < 30) {
				mostrarCorazon2 = false;
			}
			if (dist(sunnyP.getxS(), sunnyP.getyS(), 773, 250) < 30) {
				mostrarCorazon3 = false;
			}
			if (dist(sunnyP.getxS(), sunnyP.getyS(), 773, 310) < 30) {
				mostrarCorazon4 = false;
			}
			if (dist(sunnyP.getxS(), sunnyP.getyS(), 773, 360) < 30) {
				mostrarCorazon5 = false;
			}

			//MUERTE ZOMBIES
			if (dist(sunnyP.getxS(), sunnyP.getyS(), zombieN11.getxZ(), zombieN11.getyZ()) < 60) {
				estado = 10;
			}
			if (dist(sunnyP.getxS(), sunnyP.getyS(), zombieN12.getxZ(), zombieN12.getyZ()) < 60) {
				estado = 10;
			}
			if (dist(sunnyP.getxS(), sunnyP.getyS(), zombieN13.getxZ(), zombieN13.getyZ()) < 60) {
				estado = 10;
			}
			if (dist(sunnyP.getxS(), sunnyP.getyS(), zombieN14.getxZ(), zombieN14.getyZ()) < 60) {
				estado = 10;
			}


		}

		// FIN KEYPRESSED DEL NIVEL 1

		// KEYPRESSED DEL NIVEL 2
		if (estado == 2) {

			// mover personaje
			if (moverArN1 == true) {
				if (key == 'w' || key == 'W') {
					sunnyN2.moverArriba();
				}
			}
			if (moverAbN1 == true) {
				if (key == 's' || key == 'S') {
					sunnyN2.moverAbajo();
				}
			}

			if (moverAd1 == true) {
				if (key == 'd' || key == 'D') {
					sunnyN2.moverAdelante();
				}
			}

			if (moverAt1 == true) {
				if (key == 'a' || key == 'A') {
					sunnyN2.moverAtras();
				}
			}
			
			// MOVIMIENTO

			// espacio de movimiento
			if (sunnyN2.getX() < 1200 && sunnyN2.getY() < 700 && sunnyN2.getX() > 30 && sunnyN2.getY() > 125) {
				moverAt1 = true;
				moverAd1 = true;
				moverArN1 = true;
				moverAbN1 = true;
			}

			// Verticalmente hablando

			// frente
			// PRIMER OBSTACULO LABERINTOSO
			if (sunnyN2.getX() < 140 && sunnyN2.getY() < 315 && sunnyN2.getX() > 70 && sunnyN2.getY() > 115) {

				moverAd1 = false;

				// SEGUNDO OBSTACULO LABERINTOSO
			} else if (sunnyN2.getX() < 290 && sunnyN2.getY() < 480 && sunnyN2.getX() > 250 && sunnyN2.getY() > 320) {

				moverAd1 = false;

			} else if (sunnyN2.getX() < 150 && sunnyN2.getY() < 500 && sunnyN2.getX() > 90 && sunnyN2.getY() > 440) {

				moverAd1 = false;
				// TERCER OBSTACULO LABERINTOSO
			} else if (sunnyN2.getX() < 390 && sunnyN2.getY() < 460 && sunnyN2.getX() > 340 && sunnyN2.getY() > 120) {

				moverAd1 = false;

				// CUARTO OBSTACULO LABERINTOSO
			} else if (sunnyN2.getX() < 500 && sunnyN2.getY() < 420 && sunnyN2.getX() > 450 && sunnyN2.getY() > 220) {

				moverAd1 = false;
			} else if (sunnyN2.getX() < 970 && sunnyN2.getY() < 450 && sunnyN2.getX() > 890 && sunnyN2.getY() > 270) {

				moverAd1 = false;
				//QUINTO OBSTACULO LABERINTOSO
			} else  if (sunnyN2.getX() < 1050 && sunnyN2.getY() < 460 && sunnyN2.getX() > 980 && sunnyN2.getY() > 200) {

				moverAd1 = false;
			} else {
				moverAd1 = true;
			}


			// atras
			// PRIMER OBSTACULO LABERINTOSO
			if (sunnyN2.getX() < 170 && sunnyN2.getY() < 300 && sunnyN2.getX() > 70 && sunnyN2.getY() > 115) {

				moverAt1 = false;
			} else if (sunnyN2.getX() < 250 && sunnyN2.getY() < 320 && sunnyN2.getX() > 210 && sunnyN2.getY() > 260) {

				moverAt1 = false;

				// SEGUNDO OBSTACULO LABERINTOSO

			} else if (sunnyN2.getX() < 330 && sunnyN2.getY() < 500 && sunnyN2.getX() > 300 && sunnyN2.getY() > 320) {

				moverAt1 = false;

			} else // limitacion para moverse a la izquierda

			if (sunnyN2.getX() < 30 && sunnyN2.getY() < 700 && sunnyN2.getX() > 0 && sunnyN2.getY() > 125) {
				moverAt1 = false;
			// TERCER OBTACULO LABERINTOSO	
			} else if (sunnyN2.getX() < 430 && sunnyN2.getY() < 445 && sunnyN2.getX() > 370 && sunnyN2.getY() > 135) {
					moverAt1 = false;
			} else if (sunnyN2.getX() < 750 && sunnyN2.getY() < 140 && sunnyN2.getX() > 710 && sunnyN2.getY() > 115) {
				moverAt1 = false;
				// CUARTO OBSTACULO LABERINTOSO
		    } else if (sunnyN2.getX() < 530 && sunnyN2.getY() < 420 && sunnyN2.getX() > 500 && sunnyN2.getY() > 270) {
				moverAt1 = false;
		    } else if (sunnyN2.getX() < 960 && sunnyN2.getY() < 460 && sunnyN2.getX() > 910 && sunnyN2.getY() > 220) {
				moverAt1 = false;
		    } else if (sunnyN2.getX() < 1070 && sunnyN2.getY() < 450 && sunnyN2.getX() > 1030 && sunnyN2.getY() > 210) {
				moverAt1 = false;
		    } else {
				moverAt1 = true;
			}

			// HORIZONTALMENTE HABLANDO
			// arriba

			// limitaciones para moverse arriba
			if (sunnyN2.getX() < 1200 && sunnyN2.getY() < 130 && sunnyN2.getX() > 0 && sunnyN2.getY() > 0) {
				moverArN1 = false;
				// PRIMER OBSTACULO LABERINTOSO
			} else if (sunnyN2.getX() < 230 && sunnyN2.getY() < 340 && sunnyN2.getX() > 95 && sunnyN2.getY() > 300) {

				moverArN1 = false;

				// SEGUNDO OBSTACULO LABERINTOSO
			} else if (sunnyN2.getX() < 310 && sunnyN2.getY() < 520 && sunnyN2.getX() > 110 && sunnyN2.getY() > 480) {

				moverArN1 = false;
				
				// TERCER OBSTACULO LABERINTOSO
			} else if (sunnyN2.getX() < 410 && sunnyN2.getY() < 480 && sunnyN2.getX() > 365 && sunnyN2.getY() > 440) {

				moverArN1 = false;
			} else if (sunnyN2.getX() < 720 && sunnyN2.getY() < 150 && sunnyN2.getX() > 400 && sunnyN2.getY() > 120) {

				moverArN1 = false;
				
				//CUARTO OBSTACULO LABERINTOSO
			} else if (sunnyN2.getX() < 930 && sunnyN2.getY() < 310 && sunnyN2.getX() > 500 && sunnyN2.getY() > 260) {

				moverArN1 = false;
			} else if (sunnyN2.getX() < 510 && sunnyN2.getY() < 440 && sunnyN2.getX() > 470 && sunnyN2.getY() > 400) {

				moverArN1 = false;
			} else if (sunnyN2.getX() < 950 && sunnyN2.getY() < 480 && sunnyN2.getX() > 910 && sunnyN2.getY() > 420) {

				moverArN1 = false;
			} else if (sunnyN2.getX() < 1050 && sunnyN2.getY() < 480 && sunnyN2.getX() > 990 && sunnyN2.getY() > 440) {

				moverArN1 = false;
			} else {

				moverArN1 = true; }
	// abajo
			// limitacion para moverse hacia abajo
			if (sunnyN2.getX() < 1200 && sunnyN2.getY() < 700 && sunnyN2.getX() > 0 && sunnyN2.getY() > 520) {
				moverAbN1 = false;
				// PRIMER OBSTACULO LABERINTOSO
			} else if (sunnyN2.getX() < 230 && sunnyN2.getY() < 300 && sunnyN2.getX() > 110 && sunnyN2.getY() > 240) {

				moverAbN1 = false;
			} else
			// SEGUNDO OBSTACULO LABERINTOSO
			if (sunnyN2.getX() < 290 && sunnyN2.getY() < 500 && sunnyN2.getX() > 110 && sunnyN2.getY() > 420) {

				moverAbN1 = false;
			} else if (sunnyN2.getX() < 310 && sunnyN2.getY() < 340 && sunnyN2.getX() > 270 && sunnyN2.getY() > 310) {

				moverAbN1 = false;
			} else if (sunnyN2.getX() < 950 && sunnyN2.getY() < 300 && sunnyN2.getX() > 470 && sunnyN2.getY() > 200) {

				moverAbN1 = false;
			} else if (sunnyN2.getX() < 1050 && sunnyN2.getY() < 280 && sunnyN2.getX() > 990 && sunnyN2.getY() > 190) {

				moverAbN1 = false;
			} else {
				moverAbN1 = true;
			}
			
			// recoger armas
			if (dist(sunnyN2.getX(), sunnyN2.getY(), 130, 126) < 30) {

				mostrarN1 = false;

			}

			if (dist(sunnyN2.getX(), sunnyN2.getY(), 505, 289) < 30) {

				mostrarN2 = false;

			}

			// perder repetir juego

			if (dist(sunnyN2.getX(), sunnyN2.getY(), zombieN1.getX(), zombieN1.getY()) < 60) {
				estado = 10;
			}
			if (dist(sunnyN2.getX(), sunnyN2.getY(), zombieN2.getX(), zombieN2.getY()) < 60) {
				estado = 10;
			}
			if (dist(sunnyN2.getX(), sunnyN2.getY(), zombieN3.getX(), zombieN3.getY()) < 60) {
				estado = 10;
			}


		}
		// FIN KEYPRESSED DEL NIVEL 2

		// KEYPRESSED DEL NIVEL 3
		if (estado == 3) {

		}
		// FIN KEYPRESSED DEL NIVEL 3

		// KEYPRESSED DEL NIVEL 4
		if (estado == 4) {
			

		}
		// FIN KEYPRESSED DEL NIVEL 4

		// KEYPRESSED DE LOS NIVELES 5 Y 6
		if (estado == 5) {
			if (moverAr1 == true) {
				if (key == 'w' || key == 'W') {
					sunny.moverArriba();
				}
			}
			if (moverAb1 == true) {
				if (key == 's' || key == 'S') {
					sunny.moverAbajo();
				}
			}
			if (key == 'd' || key == 'D') {
				sunny.moverAdelante();
			}

			// limitacion para moverse hacia arriba
			if (sunny.getX() < 1200 && sunny.getY() < 180 && sunny.getX() > 0 && sunny.getY() > 0) {
				moverAr1 = false;
			}
			if (sunny.getX() < 1200 && sunny.getY() < 500 && sunny.getX() > 0 && sunny.getY() > 180) {
				moverAr1 = true;
			}
			// limitacion para moverse hacia abajo
			if (sunny.getX() < 1200 && sunny.getY() < 700 && sunny.getX() > 0 && sunny.getY() > 475) {
				moverAb1 = false;
			}
			if (sunny.getX() < 1200 && sunny.getY() < 475 && sunny.getX() > 0 && sunny.getY() > 180) {
				moverAb1 = true;
			}

		}

		if (estado == 6) {

			if (espada == 0) {

				if (moverAr2 == true) {
					if (key == 'w' || key == 'W') {
						sunnyespada.moverArriba();
					}
				}
				if (moverAb2 == true) {
					if (key == 's' || key == 'S') {
						sunnyespada.moverAbajo();
					}
				}

				if (key == 'd' || key == 'D') {
					sunnyespada.moverAdelante();
				}

				// limitacion para moverse hacia arriba
				if (sunnyespada.getX() < 1200 && sunnyespada.getY() < 180 && sunnyespada.getX() > 0
						&& sunnyespada.getY() > 0) {
					moverAr2 = false;
				}
				if (sunnyespada.getX() < 1200 && sunnyespada.getY() < 500 && sunnyespada.getX() > 0
						&& sunnyespada.getY() > 180) {
					moverAr2 = true;
				}
				// limitacion para moverse hacia abajo
				if (sunnyespada.getX() < 1200 && sunnyespada.getY() < 700 && sunnyespada.getX() > 0
						&& sunnyespada.getY() > 475) {
					moverAb2 = false;
				}
				if (sunnyespada.getX() < 1200 && sunnyespada.getY() < 475 && sunnyespada.getX() > 0
						&& sunnyespada.getY() > 180) {
					moverAb2 = true;
				}

			}
		}

		if (daga == 0) {
			if (moverAr3 == true) {
				if (key == 'w' || key == 'W') {
					sunnydaga.moverArriba();
				}
			}
			if (moverAb3 == true) {
				if (key == 's' || key == 'S') {
					sunnydaga.moverAbajo();
				}
			}
			/**
			 * if (key == 'd' || key == 'D') { sunnydaga.moverAdelante(); }
			 **/

			// limitacion para moverse hacia arriba
			if (sunnydaga.getX() < 1200 && sunnydaga.getY() < 180 && sunnydaga.getX() > 0 && sunnydaga.getY() > 0) {
				moverAr3 = false;
			}
			if (sunnydaga.getX() < 1200 && sunnydaga.getY() < 500 && sunnydaga.getX() > 0 && sunnydaga.getY() > 180) {
				moverAr3 = true;
			}
			// limitacion para moverse hacia abajo
			if (sunnydaga.getX() < 1200 && sunnydaga.getY() < 700 && sunnydaga.getX() > 0 && sunnydaga.getY() > 475) {
				moverAb3 = false;
			}
			if (sunnydaga.getX() < 1200 && sunnydaga.getY() < 475 && sunnydaga.getX() > 0 && sunnydaga.getY() > 180) {
				moverAb3 = true;
			}

		}

		// FIN DEL KEYPRESSED DE LOS NIVELES 5 Y 6

		// KEYPRESSED DEL NIVEL 8
		if (estado == 8) {

		}
		// FIN KEYPRESSED DEL NIVEL 8

		// KEYPRESSED DEL NIVEL 9
		if (estado == 9) {

		}
		// FIN KEYPRESSED DEL NIVEL 9
	}

	public void mouseDragged() {

		if (estado == 7) {
			if (pi1 != null) {

				p1.setX(mouseX);
				p1.setY(mouseY);

			}

			if (pi2 != null) {

				p2.setX(mouseX);
				p2.setY(mouseY);

			}

			if (pi3 != null) {

				p3.setX(mouseX);
				p3.setY(mouseY);

			}

			if (pi4 != null) {

				p4.setX(mouseX);
				p4.setY(mouseY);

			}

			if (pi5 != null) {

				p5.setX(mouseX);
				p5.setY(mouseY);

			}

		}
	}

	@Override
	public void mouseReleased() {

		if (estado == 7) {
			if (p1.getX() > cuadro1.getX() && p1.getX() < cuadro1.getX() + 124 && p1.getY() > cuadro1.getY()
					&& p1.getY() < cuadro1.getY() + 374) {

				p1 = new Piezas(this, 720, 147);
				pi1 = null;
				puntos += 1;

			}

			if (p2.getX() > cuadro2.getX() && p2.getX() < cuadro2.getX() + 124 && p2.getY() > cuadro2.getY()
					&& p2.getY() < cuadro2.getY() + 125) {

				p2 = new Piezas(this, 844, 147);
				pi2 = null;
				puntos += 1;

			}

			if (p3.getX() > cuadro3.getX() && p3.getX() < cuadro3.getX() + 124 && p3.getY() > cuadro3.getY()
					&& p3.getY() < cuadro3.getY() + 125) {

				p3 = new Piezas(this, 968, 147);
				pi3 = null;
				puntos += 1;

			}

			if (p4.getX() > cuadro4.getX() && p4.getX() < cuadro4.getX() + 248 && p4.getY() > cuadro4.getY()
					&& p4.getY() < cuadro4.getY() + 125) {

				p4 = new Piezas(this, 844, 271);
				pi4 = null;
				puntos += 1;

			}
			if (p5.getX() > cuadro5.getX() && p5.getX() < cuadro5.getX() + 248 && p5.getY() > cuadro5.getY()
					&& p5.getY() < cuadro5.getY() + 125) {

				p5 = new Piezas(this, 844, 396);
				pi5 = null;

				puntos += 1;

			}

		}
	}
	
	@Override
	public void mouseMoved(MouseEvent event) {
		if (estado ==4) {
			
			if (click==2)
			capturador.setX(mouseX);
			
			if (capturador.getX()<0) {
				
				capturador.setX(0);
			} 
			
			if (capturador.getX()>1200) {
				
				
				capturador.setX(1200);
			}
			}
		} 
	

}
