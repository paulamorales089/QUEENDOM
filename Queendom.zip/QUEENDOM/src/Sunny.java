import processing.core.PApplet;
import processing.core.PImage;

public class Sunny {

	int x, y;
	//SUNNY TAMANO GRANDE
	private PImage sunnynede;
	private PImage sunnyesp;
	private PImage sunnydaga;

	//SUNNY TAMANO CHIQUITA 
	public PImage min;

	public Sunny(PApplet app,int x, int y) {
		//SUNNY TAMANO GRANDE
		sunnynede = app.loadImage("data/sunnynede.png");
		sunnyesp = app.loadImage("data/sunnyesp.png");
		sunnydaga = app.loadImage("data/sunnydaga.png");
		
		//SUNNY CHIQUITA NIVEL 2
		
		min = app.loadImage("data/min1.png");

		this.x = x;
		this.y = y;
	}
     //METODOS PARA SUNNY TAMANO GRANDE
     	public void pintar(PApplet app) {
		app.imageMode (app.CENTER);
		app.image(sunnynede, x, y);
		app.imageMode (app.CORNER);
		
		
	}
     	
     	public void pintar1(PApplet app) {
     		//METODOS PARA SUNNY TAMANO CHIQUITA NIVEL 2
    		min.resize(0, 80);
    		app.imageMode(app.CENTER);
    		app.image(min,x,y);
    		app.imageMode(app.CORNER);
     		
     	}
     	
     	
	
	public void pintarEspada(PApplet app) {
		app.imageMode (app.CENTER);
		app.image(sunnyesp, x, y);
		app.imageMode (app.CORNER);
	}
	public void pintarDaga(PApplet app) {
		app.imageMode (app.CENTER);
		app.image(sunnydaga, x, y);
		app.imageMode (app.CORNER);
	}
	public void moverArriba() {

		y -= 20;
	}

	public void moverAbajo() {

		y += 20;
	}
	
	public void moverAdelante() {

		x += 20;
	}
	
	public void moverAtras() {

		x -= 20;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

}
