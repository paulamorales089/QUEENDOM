import processing.core.PApplet;
import processing.core.PImage;

public class Principal extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Principal");
	}

	@Override
	public void settings() {
		size(1200, 700);
	}

	int estado = 0; // PANTALLAS

	// NIVEL 2
	PImage fondo2;

	PImage arma1;
	PImage arma2;

	Sunny sunnyN2;
	Zombies zombieN1;
	Zombies zombieN2;
	Zombies zombieN3;

	// movimiento sunny
	boolean moverArN1 = true;
	boolean moverAbN1 = true;

	// zombie1
	boolean moverArN2 = true;
	boolean moverAbN2 = true;
	// zombie2
	boolean moverAd1 = true;
	boolean moverAt1 = true;
	// zombie3
	boolean moverAr4 = true;
	boolean moverAb4 = true;

	boolean mostrarN1 = true;
	boolean mostrarN2 = true;

	int px, py;

	int x, y;
	int x2, y2;
	int x3, y3;

	int Rx1, Ry1;
	int Rx2, Ry2;

	int LP, LP2;

	// FIN VARIABLES NIVEL 2
	// NIVELES 5 Y 6
	// Nivel 5
	Sunny sunny;
	Sunny sunnyespada;
	Sunny sunnydaga;

	// nivel 5
	// carril1
	Zombies zombie1;
	Zombies zombie2;

	// carril2
	Zombies zombie3;

	// carril3
	Zombies zombie4;
	Zombies zombie5;

	// nivel6
	// carril1
	Zombies zombie1A;
	Zombies zombie2A;

	// carril2
	Zombies zombie3A;

	// carril3
	Zombies zombie4A;
	Zombies zombie5A;

	// VARIABLES NIVELES 5 Y 6
	int mostrar;
	boolean mostrar1 = true;
	boolean mostrar2 = true;
	boolean mostrar3 = true;
	boolean mostrar4 = true;
	boolean mostrar5 = true;
	int espada = 0;
	int daga = 0;
	boolean moverAr1 = true;
	boolean moverAb1 = true;
	boolean moverAr2 = true;
	boolean moverAb2 = true;
	boolean moverAr3 = true;
	boolean moverAb3 = true;
	boolean perder = true;
	// FIN DE LAS VARIABLES DE LOS NIVELES 5 Y 6

	// NIVEL 7
	PImage fondo7;

	PImage personaje;
	PImage cofre;
	PImage corazon;

	Cuadros cuadro1;
	Cuadros cuadro2;
	Cuadros cuadro3;
	Cuadros cuadro4;
	Cuadros cuadro5;

	Piezas p1;
	Piezas p2;
	Piezas p3;
	Piezas p4;
	Piezas p5;

	Piezas pi1;
	Piezas pi2;
	Piezas pi3;
	Piezas pi4;
	Piezas pi5;

	int puntos;

	// FIN DE LAS VARIABLES DE LOS NIVELES 7

	// IMAGENES DE FONDO
	private PImage PRINCIPAL;
	private PImage NIVEL5;
	private PImage NIVEL6;
	private PImage PERDIO;
	private PImage GANO;

	@Override
	public void setup() {

		// FONDOS GENERALES
		PRINCIPAL = loadImage("data/PRINCIPAL.png");
		PERDIO = loadImage("data/PERDIO.png");
		GANO = loadImage("data/GANO.png");

		// LLAMAR NIVEL 2
		// images level 2
		fondo2 = loadImage("NIVEL 2.png");

		arma2 = loadImage("daga.png");
		arma1 = loadImage("espada.png");

		px = 30;
		py = 300;

		x = 481;
		y = 490;

		x2 = 970;
		y2 = 130;

		x3 = 122;
		y3 = 213;

		Rx1 = 651;
		Ry1 = 13;

		Rx2 = 754;
		Ry2 = 13;

		sunnyN2 = new Sunny(this, px, py);

		zombieN3 = new Zombies(this, x3, y3);
		zombieN2 = new Zombies(this, x2, y2);
		zombieN1 = new Zombies(this, x, y);

		estado = 0;

		LP = 0;
		LP2 = 0;
		// FIN LLAMAR NIVEL 2

		// LLAMAR CLASES EN LOS NIVELES 5 Y 6

		// FONDOSNIVELES 5 Y 6
		NIVEL5 = loadImage("data/NIVEL 5.png");
		NIVEL6 = loadImage("data/NIVEL 6.png");

		// Sunny
		// nivel 5
		sunny = new Sunny(this, 10, 300);
		System.out.println(sunny);

		// nivel 6
		sunnyespada = new Sunny(this, 90, 300);
		System.out.println(sunnyespada);

		sunnydaga = new Sunny(this, 90, 300);
		System.out.println(sunnydaga);

		// Zombies NIVEL 5
		zombie1 = new Zombies(this, 1156, 170);
		System.out.println(zombie1);
		zombie2 = new Zombies(this, 1156, 170);
		System.out.println(zombie2);

		zombie3 = new Zombies(this, 1156, 329);
		System.out.println(zombie3);

		zombie4 = new Zombies(this, 1156, 470);
		System.out.println(zombie4);
		zombie5 = new Zombies(this, 1156, 470);
		System.out.println(zombie5);

		// Zombies NIVEL 6
		zombie1A = new Zombies(this, 1156, 170);
		System.out.println(zombie1A);
		zombie2A = new Zombies(this, 1156, 170);
		System.out.println(zombie2A);

		zombie3A = new Zombies(this, 1156, 329);
		System.out.println(zombie3A);

		zombie4A = new Zombies(this, 1156, 470);
		System.out.println(zombie4A);
		zombie5A = new Zombies(this, 1156, 470);
		System.out.println(zombie5A);
		// FIN DE LLAMAR A LOS NIVELES 5 Y 6

		// LLAMAR CLASES NIVEL 7
		fondo7 = loadImage("NIVEL 7.png");

		corazon = loadImage("corazon.png");

		personaje = loadImage("min2.png");
		cofre = loadImage("cofre.png");
		corazon = loadImage("corazon.png");

		cuadro1 = new Cuadros(720, 147, 124, 374);
		cuadro2 = new Cuadros(844, 147, 124, 125);
		cuadro3 = new Cuadros(968, 147, 124, 125);
		cuadro4 = new Cuadros(844, 271, 248, 125);
		cuadro5 = new Cuadros(844, 396, 248, 125);

		p1 = new Piezas(this, 422, 91);
		p2 = new Piezas(this, 555, 91);
		p3 = new Piezas(this, 555, 239);
		p4 = new Piezas(this, 555, 394);
		p5 = new Piezas(this, 133, 91);

		pi1 = null;
		pi2 = null;
		pi3 = null;
		pi4 = null;
		pi5 = null;

		puntos = 0;
		// FIN DE LLAMAR EL NIVEL 7
	}

	@Override
	public void draw() {
		background(255);

		// Pantalla principal
		if (estado == 0) {
			image(PRINCIPAL, 0, 0);
		}

		// Nivel 1 //Paula
		if (estado == 1) {

			// condicion si pierde
			/**
			 * if (condicion) { estado = 10;
			 * 
			 * }
			 **/

			// condicion si gana
			/**
			 * if (condicion) { estado = 2;
			 * 
			 * }
			 **/

		}

		// Nivel 2 //Laura
		if (estado == 2) {

			// scenario level 2
			imageMode(CENTER);
			image(fondo2, 600, 350);
			imageMode(CORNER);

			sunnyN2.pintar1(this);

			zombieN3.pintar3(this);
			zombieN3.moverN21(this);

			zombieN2.pintar2(this);
			zombieN2.moverN22(this);

			zombieN1.pintar3(this);
			zombieN1.moverN23(this);

			if (mostrarN1 == true) {

				noStroke();
				fill(96, 159, 144);
				rect(Rx1, Ry1, 41, 45);
				image(arma1, 130, 126);

			}

			if (mostrarN2 == true) {

				noStroke();
				fill(96, 159, 144);
				rect(Rx2, Ry2, 41, 45);
				image(arma2, 505, 289);
			}

			if (mostrarN1 == false) {

				noStroke();
				fill(96, 159, 144);
				rect(Rx2 + 41, Ry2, 42, 42);
				LP = 2;

			}

			if (mostrarN2 == false) {

				noStroke();
				fill(96, 159, 144);
				rect(Rx1 + 41, Ry1, 42, 42);
				LP2 = 2;

			}

			if (LP == 2 && LP2 == 2) {

				if (sunnyN2.getX() < 1200 && sunnyN2.getY() < 562 && sunnyN2.getX() > 1169 && sunnyN2.getY() > 110) {

					estado=3;
				}

			}

			System.out.println(LP);
			System.out.println(LP2);
			

			// condicion si pierde
			/**
			 * if (condicion) { estado = 10;
			 * 
			 * }
			 **/

			// condicion si gana
			/**
			 * if (condicion) { estado = 3;
			 * 
			 * }
			 **/

		}

		// Nivel 3 //Majo
		if (estado == 3) {

			// condicion si pierde
			/**
			 * if (condicion) { estado = 10;
			 * 
			 * }
			 **/
			// condicion si gana
			/**
			 * if (condicion) { estado = 4;
			 * 
			 * }
			 **/

		}
		// Nivel 4 //Majo
		if (estado == 4) {

			// condicion si pierde
			/**
			 * if (condicion) { estado = 10;
			 * 
			 * }
			 **/

			// condicion si gana
			/**
			 * if (condicion) { estado = 5;
			 * 
			 * }
			 **/

		}
		// Nivel 5 //Lina
		if (estado == 5) {

			// carretera nivel 5
			image(NIVEL5, 0, 0);
			// pintar Sunny

			sunny.pintar(this);

			// pintar zombies

			zombie1.pintar(this);
			zombie2.pintar(this);
			zombie3.pintar(this);
			zombie4.pintar(this);
			zombie5.pintar(this);

			zombie1.mover3();
			zombie2.mover1();
			zombie3.mover2();
			zombie4.mover3();
			zombie5.mover1();

			// perder repetir el juego

			if (dist(sunny.getX(), sunny.getY(), zombie1.getX(), zombie1.getY()) < 80) {
				estado = 10;
			}
			if (dist(sunny.getX(), sunny.getY(), zombie2.getX(), zombie2.getY()) < 80) {
				estado = 10;
			}
			if (dist(sunny.getX(), sunny.getY(), zombie3.getX(), zombie3.getY()) < 80) {
				estado = 10;
			}
			if (dist(sunny.getX(), sunny.getY(), zombie4.getX(), zombie4.getY()) < 80) {
				estado = 10;
			}
			if (dist(sunny.getX(), sunny.getY(), zombie5.getX(), zombie5.getY()) < 80) {
				estado = 10;

			}

			// condicion si gana

			// ganar pasar nivel 6
			if (sunny.getX() > 1200) {
				estado = 6;

			}

		}
		// Nivel 6 //Lina
		if (estado == 6) {
			// carretera nivel 6

			image(NIVEL6, 0, 0);

			if (mostrar == 0) {
				sunnyespada.pintarEspada(this);
				noFill();
				rect(624, 8, 60, 50);
			}

			if (mostrar == 1) {
				sunnyespada.pintarDaga(this);
				noFill();
				rect(724, 8, 60, 50);
			}

			// pintar zombies
			if (mostrar1 == true) {
				zombie1A.pintar(this);
			}
			if (mostrar2 == true) {
				zombie2A.pintar(this);
			}
			if (mostrar3 == true) {
				zombie3A.pintar(this);
			}
			if (mostrar4 == true) {
				zombie4A.pintar(this);
			}
			if (mostrar5 == true) {
				zombie5A.pintar(this);
			}
			zombie1A.mover4();
			zombie2A.mover5();
			zombie3A.mover6();
			zombie4A.mover5();
			zombie5A.mover4();

			if (espada == 0) {

				if (perder == true) {
					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie1A.getX(), zombie1A.getY()) < 80) {
						estado = 10;
					}

					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie2A.getX(), zombie2A.getY()) < 80) {
						estado = 10;
					}

					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie3A.getX(), zombie3A.getY()) < 80) {
						estado = 10;
					}

					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie4A.getX(), zombie4A.getY()) < 80) {
						estado = 10;
					}

					if (dist(sunnyespada.getX(), sunnyespada.getY(), zombie5A.getX(), zombie5A.getY()) < 80) {
						estado = 10;
					}
				}

				// ganar pasar nivel 7
				if (sunnyespada.getX() > 1200) {
					estado = 7;// nivel7
				}
			}

			if (daga == 0) {

				if (perder == true) {
					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie1A.getX(), zombie1A.getY()) < 80) {
						estado = 10;
					}

					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie2A.getX(), zombie2A.getY()) < 80) {
						estado = 10;
					}

					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie3A.getX(), zombie3A.getY()) < 80) {
						estado = 10;
					}

					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie4A.getX(), zombie4A.getY()) < 80) {
						estado = 10;
					}

					if (dist(sunnydaga.getX(), sunnydaga.getY(), zombie5A.getX(), zombie5A.getY()) < 80) {
						estado = 10;
					}
				}
			}

			// ganar pasar nivel 7
			if (sunnydaga.getX() > 1200) {
				estado = 7;
			}

		}
		// Nivel 7 //Laura
		if (estado == 7) {

			image(fondo7, 0, 0);

			cuadro1.pintar(this);
			cuadro2.pintar(this);
			cuadro3.pintar(this);
			cuadro4.pintar(this);
			cuadro5.pintar(this);

			personaje.resize(0, 400);
			imageMode(CENTER);
			image(personaje, 270, 400);
			imageMode(CORNER);

			p1.pintar1(this);
			p2.pintar2(this);
			p3.pintar3(this);
			p4.pintar4(this);
			p5.pintar5(this);

			// ganar el nivel 7 y pasar al 8
			if (puntos == 5) {
				corazon.resize(0, 100);
				image(corazon, 250, 150);
			}

		}
		// Nivel 8 //Paula
		if (estado == 8) {

			// condicion si pierde
			/**
			 * if (condicion) { estado = 10;
			 * 
			 * }
			 **/

			// condicion si gana
			/**
			 * if (condicion) { estado = 9;
			 * 
			 * }
			 **/

		}
		// Nivel 9 //Paula
		if (estado == 9) {

			// condicion si pierde
			/**
			 * if (condicion) { estado = 10;
			 * 
			 * }
			 **/

			// condicion si gana
			/**
			 * if (condicion) { estado = 11;
			 * 
			 * }
			 **/
		}
		// PIERDE el juego
		if (estado == 10) {
			image(PERDIO, 0, 0);
		}

		// GANA el juego
		if (estado == 11) {
			image(GANO, 0, 0);
		}

	}
	// System.out.println(mouseX + "," + mouseY);

	@Override
	public void mousePressed() {

		// MOUSEPRESSED GENERAL
		// Boton de jugar
		if (dist(mouseX, mouseY, 597, 556) < 20) {
			estado = 6;
		}
		// perder boton reintentar
		if (estado == 10) {
			if (dist(mouseX, mouseY, 618, 475) < 30) {
				estado = 0;
			}
		}
		// FIN DEL MOUSEPRESSED GENERAL

		// MOUSEPRESSED NIVEL 3
		if (estado == 3) {

		}
		// FIN DEL MOUSEPRESSED DEL NIVEL 3

		// MOUSEPRESSED NIVEL 6
		// seleccion de armas
		// espada
		if (estado == 6) {
			if (dist(mouseX, mouseY, 651, 38) < 20) {
				// pintar Sunny con espada
				if (espada == 0) {
					mostrar = 0;
				}
			}
			// daga

			if (dist(mouseX, mouseY, 751, 40) < 20) {
				// pintar Sunny con dagas
				if (daga == 0) {
					mostrar = 1;
				}
			}

			// Matar a los zombies

			if (espada == 0) {
				// espada
				if (dist(mouseX, mouseY, zombie1A.getX(), zombie1A.getY()) < 120) {
					mostrar1 = false;
					perder = false;
				}

				if (dist(mouseX, mouseY, zombie2A.getX(), zombie2A.getY()) < 120) {
					mostrar2 = false;
					perder = false;
				}
				if (dist(mouseX, mouseY, zombie3A.getX(), zombie3A.getY()) < 120) {
					mostrar3 = false;
					perder = false;
				}

				if (dist(mouseX, mouseY, zombie4A.getX(), zombie4A.getY()) < 120) {
					mostrar4 = false;
					perder = false;
				}
				if (dist(mouseX, mouseY, zombie5A.getX(), zombie5A.getY()) < 120) {
					mostrar5 = false;
					perder = false;
				}

			}

			if (daga == 0) {
				// daga
				if (dist(mouseX,mouseY,zombie1A.getX(), zombie1A.getY())<20) {
					if(dist(sunnydaga.getX(), sunnydaga.getY(), zombie1A.getX(), zombie1A.getY()) == 5) {
					mostrar1 = false;
					perder = false;
					
					}
				}

				if (dist(mouseX,mouseY,zombie2A.getX(), zombie2A.getY())<20) {
					
					if(dist(sunnydaga.getX(), sunnydaga.getY(), zombie2A.getX(), zombie2A.getY()) == 5) {
					mostrar2 = false;
					perder = false;
					}
				}
				if (dist(mouseX,mouseY,zombie3A.getX(), zombie3A.getY())<20) {
					
					if(dist(sunnydaga.getX(), sunnydaga.getY(), zombie3A.getX(), zombie3A.getY()) == 5) {
					mostrar3 = false;
					perder = false;}
				}

				if (dist(mouseX,mouseY,zombie4A.getX(), zombie4A.getY())<20) {
					if(dist(sunnydaga.getX(), sunnydaga.getY(), zombie4A.getX(), zombie4A.getY()) == 5) {
					mostrar4 = false;
					perder = false;}
				}
				if (dist(mouseX,mouseY,zombie5A.getX(), zombie5A.getY())<20) {
					if(dist(sunnydaga.getX(), sunnydaga.getY(), zombie5A.getX(), zombie5A.getY()) == 5) {
					mostrar5 = false;
					perder = false;}
				}

			}
		}
		// FIN DEL MOUSEPRESSED DE LOS NIVELES 5 Y 6

		// MOUSEPRESSED NIVEL 7
		if (estado == 7) {
			if (dist(mouseX, mouseY, p1.getX(), p1.getY()) < 40) {

				pi1 = p1;
			}

			if (dist(mouseX, mouseY, p2.getX(), p2.getY()) < 64) {

				pi2 = p2;
			}

			if (dist(mouseX, mouseY, p3.getX(), p3.getY()) < 40) {

				pi3 = p3;
			}

			if (dist(mouseX, mouseY, p4.getX(), p4.getY()) < 40) {

				pi4 = p4;
			}

			if (dist(mouseX, mouseY, p5.getX(), p5.getY()) < 40) {

				pi5 = p5;
			}
			// PASAR NIVEL 8
			if ((dist(mouseX, mouseY,250, 150) < 60) && puntos==5) {

				estado = 8;

			}
		}

		// FIN DEL MOUSEPRESSED DEL NIVEL 7

		// MOUSEPRESSED NIVEL 8
		if (estado == 8) {

		}
		// FIN DEL MOUSEPRESSED DEL NIVEL 8

		// MOUSEPRESSED NIVEL 9
		if (estado == 9) {

		}
		// FIN DEL MOUSEPRESSED DEL NIVEL 9
	}

	@Override
	public void keyPressed() {
		// KEYPRESSED DEL NIVEL 1
		if (estado == 1) {

		}
		// FIN KEYPRESSED DEL NIVEL 1

		// KEYPRESSED DEL NIVEL 2
		if (estado == 2) {

			// mover personaje
			if (moverArN1 == true) {
				if (key == 'w' || key == 'W') {
					sunnyN2.moverArriba();
				}
			}
			if (moverAbN1 == true) {
				if (key == 's' || key == 'S') {
					sunnyN2.moverAbajo();
				}
			}

			if (moverAd1 == true) {
				if (key == 'd' || key == 'D') {
					sunnyN2.moverAdelante();
				}
			}

			if (moverAt1 == true) {
				if (key == 'a' || key == 'A') {
					sunnyN2.moverAtras();
				}
			}
			// limitacion para moverse hacia arriba
			if (sunnyN2.getX() < 1200 && sunnyN2.getY() < 120 && sunnyN2.getX() > 0 && sunnyN2.getY() > 0) {
				moverArN1 = false;
			}
			if (sunnyN2.getX() < 1200 && sunnyN2.getY() < 500 && sunnyN2.getX() > 0 && sunnyN2.getY() > 180) {
				moverArN1 = true;
			}
			// limitacion para moverse hacia abajo
			if (sunnyN2.getX() < 1200 && sunnyN2.getY() > 543 && sunnyN2.getX() > 0 && sunnyN2.getY() > 0) {
				moverAbN1 = false;
			}
			if (sunnyN2.getX() < 1200 && sunnyN2.getY() < 475 && sunnyN2.getX() > 0 && sunnyN2.getY() > 180) {
				moverAbN1 = true;
			}

			// obstaculos verticales del laberinto

			if (sunnyN2.getX() < 123 && sunnyN2.getY() < 312 && sunnyN2.getX() > 107 && sunnyN2.getY() > 126) {

				moverAd1 = false;

			} else {

				moverAd1 = true;

			}

			if (sunnyN2.getX() < 294 && sunnyN2.getY() < 486 && sunnyN2.getX() > 279 && sunnyN2.getY() > 361) {

				moverAd1 = false;

			}

			if (sunnyN2.getX() < 388 && sunnyN2.getY() < 455 && sunnyN2.getX() > 372 && sunnyN2.getY() > 128) {

				moverAd1 = false;

			}

			if (sunnyN2.getX() < 497 && sunnyN2.getY() < 424 && sunnyN2.getX() > 481 && sunnyN2.getY() > 268) {

				moverAd1 = false;

			}

			if (sunnyN2.getX() < 934 && sunnyN2.getY() < 455 && sunnyN2.getX() > 919 && sunnyN2.getY() > 268) {

				moverAd1 = false;

			}

			if (sunnyN2.getX() < 1029 && sunnyN2.getY() < 455 && sunnyN2.getX() > 1013 && sunnyN2.getY() > 236) {

				moverAd1 = false;

			}

			if (sunnyN2.getX() < 1029 && sunnyN2.getY() < 455 && sunnyN2.getX() > 1013 && sunnyN2.getY() > 236) {

				moverAd1 = false;

			}

			// obstaculos horizontales del laberinto

			if (sunnyN2.getX() < 216 && sunnyN2.getY() < 311 && sunnyN2.getX() > 106 && sunnyN2.getY() > 296) {

				moverArN1 = false;

			} else {

				moverArN1 = true;
				moverAbN1 = true;

			}
			if (sunnyN2.getX() < 294 && sunnyN2.getY() < 483 && sunnyN2.getX() > 122 && sunnyN2.getY() > 468) {

				moverAbN1 = false;

			}

			if (sunnyN2.getX() < 716 && sunnyN2.getY() < 140 && sunnyN2.getX() > 372 && sunnyN2.getY() > 124) {

				moverArN1 = false;

			}

			if (sunnyN2.getX() < 934 && sunnyN2.getY() < 280 && sunnyN2.getX() > 481 && sunnyN2.getY() > 265) {

				moverArN1 = false;

			}

			// recoger armas
			if (dist(sunnyN2.getX(), sunnyN2.getY(), 130, 126) < 60) {

				mostrarN1 = false;

			}

			if (dist(sunnyN2.getX(), sunnyN2.getY(), 505, 289) < 60) {

				mostrarN2 = false;

			}

			// perder repetir juego

			if (dist(sunnyN2.getX(), sunnyN2.getY(), zombieN1.getX(), zombieN1.getY()) < 60) {
				estado = 10;
			}
			if (dist(sunnyN2.getX(), sunnyN2.getY(), zombieN2.getX(), zombieN2.getY()) < 60) {
				estado = 10;
			}
			if (dist(sunnyN2.getX(), sunnyN2.getY(), zombieN3.getX(), zombieN3.getY()) < 60) {
				estado = 10;
			}

		}
		// FIN KEYPRESSED DEL NIVEL 2

		// KEYPRESSED DEL NIVEL 3
		if (estado == 3) {

		}
		// FIN KEYPRESSED DEL NIVEL 3

		// KEYPRESSED DEL NIVEL 4
		if (estado == 4) {

		}
		// FIN KEYPRESSED DEL NIVEL 4

		// KEYPRESSED DE LOS NIVELES 5 Y 6
		if (estado == 5) {
			if (moverAr1 == true) {
				if (key == 'w' || key == 'W') {
					sunny.moverArriba();
				}
			}
			if (moverAb1 == true) {
				if (key == 's' || key == 'S') {
					sunny.moverAbajo();
				}
			}
			if (key == 'd' || key == 'D') {
				sunny.moverAdelante();
			}

			// limitacion para moverse hacia arriba
			if (sunny.getX() < 1200 && sunny.getY() < 180 && sunny.getX() > 0 && sunny.getY() > 0) {
				moverAr1 = false;
			}
			if (sunny.getX() < 1200 && sunny.getY() < 500 && sunny.getX() > 0 && sunny.getY() > 180) {
				moverAr1 = true;
			}
			// limitacion para moverse hacia abajo
			if (sunny.getX() < 1200 && sunny.getY() < 700 && sunny.getX() > 0 && sunny.getY() > 475) {
				moverAb1 = false;
			}
			if (sunny.getX() < 1200 && sunny.getY() < 475 && sunny.getX() > 0 && sunny.getY() > 180) {
				moverAb1 = true;
			}

		}

		if (estado == 6) {

			if (espada == 0) {

				if (moverAr2 == true) {
					if (key == 'w' || key == 'W') {
						sunnyespada.moverArriba();
					}
				}
				if (moverAb2 == true) {
					if (key == 's' || key == 'S') {
						sunnyespada.moverAbajo();
					}
				}

				if (key == 'd' || key == 'D') {
					sunnyespada.moverAdelante();
				}

				// limitacion para moverse hacia arriba
				if (sunnyespada.getX() < 1200 && sunnyespada.getY() < 180 && sunnyespada.getX() > 0
						&& sunnyespada.getY() > 0) {
					moverAr2 = false;
				}
				if (sunnyespada.getX() < 1200 && sunnyespada.getY() < 500 && sunnyespada.getX() > 0
						&& sunnyespada.getY() > 180) {
					moverAr2 = true;
				}
				// limitacion para moverse hacia abajo
				if (sunnyespada.getX() < 1200 && sunnyespada.getY() < 700 && sunnyespada.getX() > 0
						&& sunnyespada.getY() > 475) {
					moverAb2 = false;
				}
				if (sunnyespada.getX() < 1200 && sunnyespada.getY() < 475 && sunnyespada.getX() > 0
						&& sunnyespada.getY() > 180) {
					moverAb2 = true;
				}

			}
		}

		if (daga == 0) {
			if (moverAr3 == true) {
				if (key == 'w' || key == 'W') {
					sunnydaga.moverArriba();
				}
			}
			if (moverAb3 == true) {
				if (key == 's' || key == 'S') {
					sunnydaga.moverAbajo();
				}
			}
			/**
			 * if (key == 'd' || key == 'D') { sunnydaga.moverAdelante(); }
			 **/

			// limitacion para moverse hacia arriba
			if (sunnydaga.getX() < 1200 && sunnydaga.getY() < 180 && sunnydaga.getX() > 0 && sunnydaga.getY() > 0) {
				moverAr3 = false;
			}
			if (sunnydaga.getX() < 1200 && sunnydaga.getY() < 500 && sunnydaga.getX() > 0 && sunnydaga.getY() > 180) {
				moverAr3 = true;
			}
			// limitacion para moverse hacia abajo
			if (sunnydaga.getX() < 1200 && sunnydaga.getY() < 700 && sunnydaga.getX() > 0 && sunnydaga.getY() > 475) {
				moverAb3 = false;
			}
			if (sunnydaga.getX() < 1200 && sunnydaga.getY() < 475 && sunnydaga.getX() > 0 && sunnydaga.getY() > 180) {
				moverAb3 = true;
			}

		}

		// FIN DEL KEYPRESSED DE LOS NIVELES 5 Y 6

		// KEYPRESSED DEL NIVEL 8
		if (estado == 8) {

		}
		// FIN KEYPRESSED DEL NIVEL 8

		// KEYPRESSED DEL NIVEL 9
		if (estado == 9) {

		}
		// FIN KEYPRESSED DEL NIVEL 9
	}

	public void mouseDragged() {

		if (estado == 7) {
			if (pi1 != null) {

				p1.setX(mouseX);
				p1.setY(mouseY);

			}

			if (pi2 != null) {

				p2.setX(mouseX);
				p2.setY(mouseY);

			}

			if (pi3 != null) {

				p3.setX(mouseX);
				p3.setY(mouseY);

			}

			if (pi4 != null) {

				p4.setX(mouseX);
				p4.setY(mouseY);

			}

			if (pi5 != null) {

				p5.setX(mouseX);
				p5.setY(mouseY);

			}

		}
	}

	@Override
	public void mouseReleased() {

		if (estado == 7) {
			if (p1.getX() > cuadro1.getX() && p1.getX() < cuadro1.getX() + 124 && p1.getY() > cuadro1.getY()
					&& p1.getY() < cuadro1.getY() + 374) {

				p1 = new Piezas(this, 720, 147);
				pi1 = null;
				puntos += 1;

			}

			if (p2.getX() > cuadro2.getX() && p2.getX() < cuadro2.getX() + 124 && p2.getY() > cuadro2.getY()
					&& p2.getY() < cuadro2.getY() + 125) {

				p2 = new Piezas(this, 844, 147);
				pi2 = null;
				puntos += 1;

			}

			if (p3.getX() > cuadro3.getX() && p3.getX() < cuadro3.getX() + 124 && p3.getY() > cuadro3.getY()
					&& p3.getY() < cuadro3.getY() + 125) {

				p3 = new Piezas(this, 968, 147);
				pi3 = null;
				puntos += 1;

			}

			if (p4.getX() > cuadro4.getX() && p4.getX() < cuadro4.getX() + 248 && p4.getY() > cuadro4.getY()
					&& p4.getY() < cuadro4.getY() + 125) {

				p4 = new Piezas(this, 844, 271);
				pi4 = null;
				puntos += 1;

			}
			if (p5.getX() > cuadro5.getX() && p5.getX() < cuadro5.getX() + 248 && p5.getY() > cuadro5.getY()
					&& p5.getY() < cuadro5.getY() + 125) {

				p5 = new Piezas(this, 844, 396);
				pi5 = null;

				puntos += 1;

			}

		}
	}

}
