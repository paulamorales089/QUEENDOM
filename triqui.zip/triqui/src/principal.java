import processing.core.PApplet;

public class principal extends PApplet {

	public static void main(String[] args) {

		PApplet.main("principal");
	}

	@Override
	public void settings() {

		size(500, 500);
	}

	Casilla[][] tablero;

	int posicion;

	int puesto;

	@Override

	public void setup() {
		tablero = new Casilla[3][3];

		for (int f = 0; f < 3; f++) {
			for (int c = 0; c < 3; c++) {
				tablero[f][c] = new Casilla((f * 166), (c * 166), 0);
			}
		}
	}

	@Override
	public void draw() {
		background(255);

		for (int f = 0; f < 3; f++) {
			for (int c = 0; c < 3; c++) {

				tablero[f][c].pintar(this);

			}
		}
	}

	@Override
	public void mouseClicked() {
		for (int f = 0; f < 3; f++) {
			for (int c = 0; c < 3; c++) {

				if (tablero[f][c].validacion(mouseX, mouseY)) {
					tablero[f][c].setTipo(1);
				}

			}

		}
	}
}
