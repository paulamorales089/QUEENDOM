import processing.core.PApplet;

public class Jugador {
	private int x, y;

	public Jugador(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public void pintarCirculo(PApplet app) {
		app.rectMode(app.CENTER);
		app.noFill();
		app.strokeWeight(3);
		app.ellipse(x, y, 50, 50);
		app.rectMode(app.CENTER);

	}

	public void pintarEquis(PApplet app) {
		app.textAlign(app.CENTER, app.CENTER);
		app.textSize(60);
		app.text("X", x, y);
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

}
