import processing.core.PApplet;

public class Casilla {

	private int x, y, tipo;

	public Casilla (int x, int y, int tipo) {
	this.x = x;
	this.y = y ;
	this.tipo = tipo;
	
	 }

	public void pintarCirculo(PApplet app) {
		app.rectMode(app.CENTER);
		app.fill(0);
		app.strokeWeight(3);
		app.ellipse(x+83, y+83, 50, 50);
		app.rectMode(app.CENTER);

	}

	public void pintarEquis(PApplet app) {
		app.textAlign(app.CENTER, app.CENTER);
		app.textSize(60);
		app.fill(0);
		app.text("X", x+83, y+83);
	}

	public void pintar(PApplet app) {
		
		app.noFill ();
		app.stroke (255,0,0);
		app.strokeWeight (3);
		app.rect (x, y, 155,155);
		
		switch (tipo) {
		case 1:
			pintarEquis(app);

			break;
		case 2:
			pintarCirculo(app);

			break;

		default:
			break;
		}
	}
	
	public boolean validacion(int vx, int vy) {
		if(vx>x && vx< x+155 && vy > y && vy<y+155){
			return true;
		}return false;
		
	}
	
	public void setTipo(int tipo) {
		this.tipo = tipo;
		
	}
}
