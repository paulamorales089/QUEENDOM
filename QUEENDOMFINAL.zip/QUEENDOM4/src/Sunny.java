import processing.core.PApplet;
import processing.core.PImage;

public class Sunny {

	int x, y;
	// SUNNY TAMANO GRANDE
	private PImage sunnynede;
	private PImage sunnyesp;
	private PImage sunnydaga;

	// SUNNY TAMANO CHIQUITA
	public PImage min;

	private int xS;
	private int yS;
	private boolean pasar;
	private boolean mostrar;

	// SUNNY CHUIQUITA NIVEL1
	private PImage suniFrente;
	private PImage suniEspalda;
	private PImage suniDerecha;
	private PImage sunnyIzquierda;
	private PImage suniEspadaDer;
	private PImage suniEspadaIzq;

	// NIVEL 8
	int xSN8, ySN8;

	private PImage sunnyEspadaN8;
	private PImage sunnyEspadaIzqN8;
	private PImage sunnyDagaN8;
	private PImage sunnyDerechaN8;
	private int vida;

	public Sunny(PApplet app, int x, int y) {
		// SUNNY TAMANO GRANDE
		sunnynede = app.loadImage("data/sunnynede.png");
		sunnyesp = app.loadImage("data/sunnyesp.png");
		sunnydaga = app.loadImage("data/sunnydaga.png");

		// SUNNY CHIQUITA NIVEL 2

		min = app.loadImage("data/min1.png");

		this.x = x;
		this.y = y;

		// NIVEL 1
		this.xS = x;
		this.yS = y;

		mostrar = true;
	
		suniDerecha = app.loadImage("sunnyDerecha.png");
		
		//NIVEL 8
		sunnyEspadaN8 = app.loadImage("sunnyNegroEspada.png");
		sunnyDagaN8 = app.loadImage("sunnyNegroDaga.png");
		sunnyEspadaIzqN8 = app.loadImage("sunnyEspadaIzq.png");
		sunnyDerechaN8= app.loadImage("sunnyDerecha.png");

		this.xSN8 = x;
		this.ySN8 = y;
		this.vida=3;
	}

	// METODOS PARA SUNNY TAMANO GRANDE
	public void pintar(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(sunnynede, x, y);
		app.imageMode(app.CORNER);

	}

	public void pintar1(PApplet app) {
		// METODOS PARA SUNNY TAMANO CHIQUITA NIVEL 2
		min.resize(0, 80);
		app.imageMode(app.CENTER);
		app.image(min, x, y);
		app.imageMode(app.CORNER);

	}

	public void pintarEspada(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(sunnyesp, x, y);
		app.imageMode(app.CORNER);
	}

	public void pintarDaga(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(sunnydaga, x, y);
		app.imageMode(app.CORNER);
	}

	public void pintarFrenteSunny(PApplet app) {
		app.imageMode(app.CENTER);
		suniDerecha.resize(0, 75);
		app.image(suniDerecha, xS, yS);
		app.imageMode(app.CORNER);
	}

	public void moverArriba() {

		y -= 20;
	}

	public void moverAbajo() {

		y += 20;
	}

	public void moverAdelante() {

		x += 20;
	}

	public void moverAtras() {

		x -= 20;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public void moverArribaN1() {

		yS -= 30;
	}

	public void moverAbajoN1() {

		yS += 30;
	}

	public void moverAdelanteN1() {

		xS += 30;
	}

	public void moverAtrasN1() {

		xS -= 30;
	}
	
	//NIVEL8 
	
	public void pintarSunnyDerecha(PApplet app) {
		app.imageMode (app.CENTER);
		sunnyDerechaN8.resize(0, 170);
		app.image(sunnyDerechaN8, xSN8, ySN8);
		app.imageMode (app.CORNER);
	}
	public void pintarSunnyEspada(PApplet app) {
		app.imageMode (app.CENTER);
		sunnyEspadaN8.resize(0, 166);
		app.image(sunnyEspadaN8, xSN8, ySN8);
		app.imageMode (app.CORNER);
	}
	public void pintarSunnyDaga(PApplet app) {
		app.imageMode (app.CENTER);
		sunnyDagaN8.resize(0, 166);
		app.image(sunnyDagaN8, xSN8, ySN8);
		app.imageMode (app.CORNER);
	}

	public int getxS() {
		return xS;
	}

	public int getyS() {
		return yS;
	}
	
	public void moverArribaN8() {

		ySN8 -= 20;
	}

	public void moverAbajoN8() {

		ySN8 += 20;
	}
	
	public void moverAdelanteN8() {

		xSN8 += 20;
	}
	public void moverAtrasN8() {

		xSN8 -= 20;
	}
	
	public int getxSN8() {
		return xSN8;
	}

	public void setxSN8(int xSN8) {
		this.xSN8 = xSN8;
	}

	public int getySN8() {
		return ySN8;
	}

	public void setySN8(int ySN8) {
		this.ySN8 = ySN8;
	}
	
	boolean validarBala (int xBala, int yBala) {
		if(xBala>xSN8 && xBala<xSN8+47 && yBala>ySN8 && yBala<ySN8+47) {
			vida-=1;
			return true;
			
		}
		return false;

	}


}
