import processing.core.PApplet;
import processing.core.PImage;

public class Recolectores {
private int x , y;
	
	private PImage Corazon; //Cabeza;
	
	private int velocidad;
	
	public Recolectores(PApplet app, int x, int y) {
		
		Corazon = app.loadImage("data/corazon.png");
		//Cabeza = app.loadImage("data/cabeza.png");
		
		this.x = x;
		this.y = y;
	
		velocidad = (int)(Math.random()*(7-1)+2);
	}
	
	public void PintarCorazon(PApplet app) {
		
		app.image(Corazon, x, y, 70, 70);
		
	}
	
	
	
	public void pintarCorazon(PApplet app, int dx, int dy) {
		
		app.image(Corazon, dx, dy);
		
	}
	
	public void mover() {
		y+=velocidad;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
}
