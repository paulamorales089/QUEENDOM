import processing.core.PApplet;
import processing.core.PImage;

public class Enemigo {
private int x , y;
	
	private PImage Cabeza;
	
	private int velocidad;
	
	public Enemigo(PApplet app, int x, int y) {

		Cabeza = app.loadImage("data/cabeza.png");
		
		this.x = x;
		this.y = y;
			
		velocidad = (int)(Math.random()*(7-1)+2);
				
	}

	public void PintarCabeza(PApplet app) {
		
		app.image(Cabeza, x+50, y+20, 70, 70);
		
	}
	
	public void pintarCabeza(PApplet app, int dx, int dy) {
		
		app.image(Cabeza, dx+4, dy+4, 50, 50);
		
	}
	
	
	
	public void mover() {
		y+=velocidad;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
}
