import processing.core.PApplet;
import processing.core.PImage;

public class ReyZombie {
	
	private int xRN8;
	private int yRN8;
	private int speedR8;
	
	private PImage reyZombie;
	
	public ReyZombie (PApplet app, int x, int y) {
		this.xRN8=x;
		this.yRN8=y;
		this.speedR8=2;
		reyZombie = app.loadImage("reyIzquierda.png");
				
	}
	public void pintarReyZombie(PApplet app ) {
		app.imageMode (app.CENTER);
		reyZombie.resize(0, 230);
		app.image(reyZombie, xRN8, yRN8);
		app.imageMode (app.CORNER);
	}
	public void moverRey (PApplet app) {

		yRN8 += speedR8;

		if (yRN8 >= 400) {
			yRN8 = 400;
			speedR8 -= 2;

		} else if (yRN8 <= 200) {
			yRN8 = 200;
			speedR8 = 2;
		}

	}
	
	public int getxRN8() {
		return xRN8;
	}
	public int getyRN8() {
		return yRN8;
	}

}
