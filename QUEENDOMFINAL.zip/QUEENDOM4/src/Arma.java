import processing.core.PApplet;

public class Arma {
	private int x;
	private int y;
	Bala bala;
	
	public Arma (PApplet APP) {
		this.x=x;
		this.y=y;
	}
	public void pintarArma1(PApplet app) {
	app.noFill();
	app.noStroke();
	app.square(987, 233, 50);
	
	if(bala !=null) {
		bala.pintarBala(app);
		bala.moverBala(x, y);
	}
		
	}
public void pintarArma2(PApplet app) {
	app.noFill();
	app.noStroke();
	app.square(1018, 292, 50);

	if(bala !=null) {
		bala.pintarBala(app);
		bala.moverBala(x, y);
	}
	}

public void pintarArma3(PApplet app) {
	app.noFill();
	app.noStroke();
	app.square(1049, 358, 50);


	if(bala !=null) {
		bala.pintarBala(app);
		bala.moverBala(x, y);
	}
}

public void pintarArma4(PApplet app) {
	app.noFill();
	app.noStroke();
	app.square(1085, 428, 50);
	

	if(bala !=null) {
		bala.pintarBala(app);
		bala.moverBala(x, y);
	}
	
}

 void disparar1 (PApplet app) {
	bala = new Bala (app, 987,258);
}
 void disparar2 (PApplet app) {
		bala = new Bala (app, 1018,317);
	}
 void disparar3 (PApplet app) {
		bala = new Bala (app, 1049,383);
	}
 void disparar4 (PApplet app) {
		bala = new Bala (app, 1085,453);
	}

}
