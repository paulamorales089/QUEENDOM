import processing.core.PApplet;
import processing.core.PImage;

public class principal extends PApplet {

	public static void main(String[] args) {

		PApplet.main("principal");
	}

	@Override
	public void settings() {

		size(1200, 700);
	}

	int[][] casillas;

// FONDO
	PImage fondo;

//X y Y DE ZOMBIES
	int xZ, xZ2;
	int yZ, yZ2;
	Sunny sunnyP;
	Zombie zombieN11, zombieN12, zombieN13, zombieN14;
	Corazon corazonZombie;
	int estado;
	
//SUNNY
	int sunnyX;
	int sunnyY;
	
//CORAZON
	int corazonX1;
	int corazonY1;
	
//DESAPARECER CORAZONES
	boolean mostrarCorazon1;
	boolean mostrarCorazon2;
	boolean mostrarCorazon3;
	boolean mostrarCorazon4;
	boolean mostrarCorazon5;

//SUMA CONTADOR CORAZONES
	int contador1;
	int contador2;
	int contador3;
	int contador4;
	int contador5;
	int contador6;
	int resultado;

//BOOLEAN DE MOVIMEINTO DE SUNNY
	boolean moverAr1 = true;
	boolean moverAb1 = true;

	boolean moverAr2 = true;
	boolean moverAb2 = true;

	boolean moverAd1 = true;
	boolean moverAt1 = true;

	boolean moverAr4 = true;
	boolean moverAb4 = true;

	@Override

	public void setup() {

//FONDO
		fondo = loadImage("NIVEL 1.png");

//PERSONAJES
		sunnyP = new Sunny(this);
		zombieN11 = new Zombie(this);
		zombieN12 = new Zombie(this);
		zombieN13 = new Zombie(this);
		zombieN14 = new Zombie(this);

//CORAZONES
		corazonZombie = new Corazon(this);

		// gets corazon y sunny
		sunnyX = sunnyP.getxS();
		sunnyY = sunnyP.getyS();
		corazonX1 = corazonZombie.getxC();
		corazonY1 = corazonZombie.getyC();

//DESAPARECER CORAZONES		
		mostrarCorazon1 = true;
		mostrarCorazon2 = true;
		mostrarCorazon3 = true;
		mostrarCorazon4 = true;
		mostrarCorazon5 = true;
		
//SUMA CONTADOR CORAZONES
		contador1 = 0;
		contador2 = 0;
		contador3 = 0;
		contador4 = 0;
		contador5 = 0;
		contador6 = 0;

	}

	@Override
	public void draw() {
		background(255);
		System.out.println(mouseX + "," + mouseY);
		// fondo
		image(fondo, 0, 0);
		// matriz
		for (int i = 0; i < 2400; i += 30) {
			for (int j = 39 * 2; j < 564; j += 30) {
				noFill();
				square(i, j, 30);
			}
		}

		sunnyP.pintarFrenteSunny(this);

//ZOMBIES ZOMBIES ZOMBIES
		zombieN11.pintarZombie1(this);
		zombieN11.moverZombie1(this);

		zombieN12.pintarZombie2(this);
		zombieN12.moverZombie2(this);

		zombieN13.pintarZombie3(this);
		zombieN13.moverZombie3(this);

		zombieN14.pintarZombie4(this);
		zombieN14.moverZombie4(this);

//CONTADOR CORAZONES (ESCRITO)
		fill(0);
		textSize(20);
		resultado = contador6 + contador1 + contador2 + contador3 + contador4 + contador5;
		text(resultado, 615, 47);
		text("/5", 626, 47);

// DESAPARECER CORAZONES
		if (mostrarCorazon1 == true) {
			corazonZombie.pintarCorazon1(this);
		}
		if (mostrarCorazon2 == true) {
			corazonZombie.pintarCorazon2(this);
		}
		if (mostrarCorazon3 == true) {
			corazonZombie.pintarCorazon3(this);
		}
		if (mostrarCorazon4 == true) {
			corazonZombie.pintarCorazon4(this);
		}
		if (mostrarCorazon5 == true) {
			corazonZombie.pintarCorazon5(this);
		}

//CONTADOR DE CORAZONES
		if (mostrarCorazon1 == false) {
			contador1 = 1;

			if (contador1 > 1) {
				contador1 = 1;
			}
		}
		if (mostrarCorazon2 == false) {
			contador2 = 1;
			if (contador2 > 1) {
				contador2 = 1;
			}
		}
		if (mostrarCorazon3 == false) {
			contador3 = 1;

			if (contador3 > 1) {
				contador3 = 1;
			}
		}
		if (mostrarCorazon4 == false) {
			contador4 = 1;

			if (contador4 > 1) {
				contador4 = 1;
			}
		}
		if (mostrarCorazon5 == false) {
			contador5 = 1;
			if (contador5 > 1) {
				contador5 = 1;
			}
		}
		
		
//SE PUEDE PASAR AL NIVEL 2

		if (resultado == 5) {
			if (sunnyP.getxS() > 1200) {
				estado = 2;
			}
		}
	}

	@Override
	public void keyPressed() {
		// sunnyP.moverSunny(this);

//MOVER PERSONAJE
		if (moverAr1 == true) {
			if (key == 'w' || key == 'W') {
				sunnyP.moverArriba();
			}
		}
		if (moverAb1 == true) {
			if (key == 's' || key == 'S') {
				sunnyP.moverAbajo();
			}
		}

		if (moverAd1 == true) {
			if (key == 'd' || key == 'D') {
				sunnyP.moverAdelante();
			}
		}

		if (moverAt1 == true) {
			if (key == 'a' || key == 'A') {
				sunnyP.moverAtras();
			}
		}

//LIMITACIONES DE MOVIMIENTO
		if (sunnyP.getxS() < 1200 && sunnyP.getyS() < 150 && sunnyP.getxS() > 0 && sunnyP.getyS() > 0) {
			moverAr1 = false;
		}
		if (sunnyP.getxS() < 1200 && sunnyP.getyS() < 500 && sunnyP.getxS() > 0 && sunnyP.getyS() > 180) {
			moverAr1 = true;
		}

//LIMITACIONES MOVIMIENTOS PARA MOVERSE HACIA ABAJO
		if (sunnyP.getxS() < 1200 && sunnyP.getyS() > 400 && sunnyP.getxS() > 0 && sunnyP.getyS() > 0) {
			moverAb1 = false;
		}
		if (sunnyP.getxS() < 1200 && sunnyP.getyS() < 475 && sunnyP.getxS() > 0 && sunnyP.getyS() > 180) {
			moverAb1 = true;

//LIMITACIONES MOVIMIENTOS ARBUSTO 1 (HORIZONTALES)
		}
		if (sunnyP.getxS() < 457 && sunnyP.getyS() > 180 && sunnyP.getxS() > 330 && sunnyP.getyS() < 430) {
			moverAr1 = false;
		}
		if (sunnyP.getxS() < 457 && sunnyP.getyS() < 230 && sunnyP.getxS() > 330 && sunnyP.getyS() > 130) {
			moverAr1 = true;
			moverAb1 = true;
		}
		if (sunnyP.getxS() < 457 && sunnyP.getyS() > 180 && sunnyP.getxS() > 330 && sunnyP.getyS() < 300) {
			moverAb1 = false;
		}

		// limitacion movimientos arbusto 1 (partes verticales)
		// ahora lo hago
		if (sunnyP.getxS() < 330 && sunnyP.getyS() > 407 && sunnyP.getxS() > 330 && sunnyP.getyS() < 230) {
			moverAd1 = false;
		}

//LIMITACIONES MOVIMIENTOS ARBUSTO 2 (HORIZONTALES)
		if (sunnyP.getxS() < 725 && sunnyP.getyS() > 180 && sunnyP.getxS() > 600 && sunnyP.getyS() < 430) {
			moverAr1 = false;
		}
		if (sunnyP.getxS() < 725 && sunnyP.getyS() < 230 && sunnyP.getxS() > 600 && sunnyP.getyS() > 130) {
			moverAr1 = true;
			moverAb1 = true;
		}
		if (sunnyP.getxS() < 725 && sunnyP.getyS() > 180 && sunnyP.getxS() > 600 && sunnyP.getyS() < 300) {
			moverAb1 = false;
		}
		// limitacion movimientos arbusto 2 (partes verticales)
				// ahora lo hago
		
//LIMITACIONES MOVIMIENTOS ARBUSTO 3 (HORIZONTALES)
		if (sunnyP.getxS() < 1030 && sunnyP.getyS() > 260 && sunnyP.getxS() > 840 && sunnyP.getyS() < 430) {
			moverAr1 = false;
		}
		if (sunnyP.getxS() < 1030 && sunnyP.getyS() < 230 && sunnyP.getxS() > 840 && sunnyP.getyS() > 130) {
			moverAr1 = true;
			moverAb1 = true;
		}
		if (sunnyP.getxS() < 1030 && sunnyP.getyS() > 230 && sunnyP.getxS() > 840 && sunnyP.getyS() < 300) {
			moverAb1 = false;
		}
		
//LIMITACIONES MOVIMIENTOS ARBUSTO 4 (HORIZONTALES)
		if (sunnyP.getxS() < 1090 && sunnyP.getyS() > 347 && sunnyP.getxS() > 967 && sunnyP.getyS() < 230) {
		moverAr1 = false;
		}


// DESAPARECER CORAZONES SI ESTAS CERCA
		if (dist(sunnyP.getxS(), sunnyP.getyS(), 1060, 370) < 30) {
			mostrarCorazon1 = false;
		}
		if (dist(sunnyP.getxS(), sunnyP.getyS(), 900, 246) < 30) {
			mostrarCorazon2 = false;
		}
		if (dist(sunnyP.getxS(), sunnyP.getyS(), 773, 250) < 30) {
			mostrarCorazon3 = false;
		}
		if (dist(sunnyP.getxS(), sunnyP.getyS(), 773, 310) < 30) {
			mostrarCorazon4 = false;
		}
		if (dist(sunnyP.getxS(), sunnyP.getyS(), 773, 360) < 30) {
			mostrarCorazon5 = false;
		}

//MUERTE ZOMBIES
		if (dist(sunnyP.getxS(), sunnyP.getyS(), zombieN11.getxZ(), zombieN11.getyZ()) < 60) {
			estado = 10;
		}
		if (dist(sunnyP.getxS(), sunnyP.getyS(), zombieN12.getxZ2(), zombieN12.getyZ2()) < 60) {
			estado = 10;
		}
		if (dist(sunnyP.getxS(), sunnyP.getyS(), zombieN13.getxZ3(), zombieN13.getyZ3()) < 60) {
			estado = 10;
		}
		if (dist(sunnyP.getxS(), sunnyP.getyS(), zombieN14.getxZ4(), zombieN14.getyZ4()) < 60) {
			estado = 10;
		}

	}

}
