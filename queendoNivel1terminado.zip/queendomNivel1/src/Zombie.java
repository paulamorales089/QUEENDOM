import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;

import processing.core.PApplet;
import processing.core.PImage;

public class Zombie {

	private int xZ,xZ2,xZ3,xZ4;
	private int yZ,yZ2,yZ3,yZ4;
	private int speed;

	private PImage zombieFrente;
	private PImage zombieEspalda;
	private PImage zombieDerecha;
	private PImage zombieIzquierda;

	
	public Zombie (PApplet app) {
	
//zombie 1 
	this.xZ=52;
	this.yZ=175;
	
//zombie 2 
	this.xZ2=203;
	this.yZ2=100;
	
//zombie 3 
	this.xZ3=472;
	this.yZ3=100;
	
//zombie 4
	this.xZ4=1058;
	this.yZ4=416;
	
	
	this.speed=2;
	
	zombieFrente = app.loadImage("zombie.png");
	zombieEspalda = app.loadImage("zombieEspalda.png");
	zombieDerecha = app.loadImage("zombieDerecha.png");
	zombieIzquierda = app.loadImage("zombieIzquierda.png");
		
	}
	
	public Zombie (int x, int y) {
		this.xZ=x;
		this.yZ=y;
		this.xZ2=x;
		this.yZ2=y;
		this.xZ3=x;
		this.yZ3=y;
	}
	
	public void pintarZombie1 (PApplet app) {
		app.image (zombieFrente,xZ,yZ);
	}
	
	public void pintarZombie2 (PApplet app) {
		app.image (zombieFrente,xZ2,yZ2);
	}
	
	public void pintarZombie3 (PApplet app) {
		app.image (zombieFrente,xZ3,yZ3);
	}
	
	public void pintarZombie4 (PApplet app) {
		zombieIzquierda.resize(0,90);
		app.image (zombieIzquierda,xZ4,yZ4);
	}
	
	public void moverZombie1 (PApplet app) {
		
		yZ+=speed;
		
		if(yZ>=435) {
			//app.image (zombieEspalda,xZ,yZ);
			yZ=435;
			speed -=2;
			
		} else if (yZ<=120) {
			//app.image(zombieFrente, xZ, yZ);
		
			yZ=120;
			speed=2;
		}	
			
	}
	public void moverZombie2(PApplet app) {
		
		yZ2+=speed;
		
		if(yZ2>=435) {
		yZ2=435;
		speed-=2;
			
		}else if (yZ2<=100){
		yZ2=100;
		speed=2;
		}
	}
	public void moverZombie3(PApplet app) {
		
		yZ3+=speed;
		
		if(yZ3>=435) {
		yZ2=435;
		speed-=2;
			
		}else if (yZ3<=100){
		yZ3=100;
		speed=2;
		}
	}
public void moverZombie4(PApplet app) {
		
		xZ4+=speed;
		
		if(xZ4>=1058) {
		xZ4=1058;
		speed-=2;
			
		}else if (xZ4<=580){
		xZ4=580;
		speed=2;
		}
	}
public int getxZ() {
	return xZ;
}
public int getyZ() {
	return yZ;
}
public int getxZ2() {
	return xZ2;
}
public int getyZ2() {
	return yZ2;
}
public int getxZ3() {
	return xZ3;
}
public int getyZ3() {
	return yZ3;
}
public int getxZ4() {
	return xZ4;
}
public int getyZ4() {
	return yZ4;
}
		
}

	

