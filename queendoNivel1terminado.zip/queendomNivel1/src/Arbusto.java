import processing.core.PApplet;
import processing.core.PImage;

public class Arbusto {
	
	private int xA;
	private int yA;
	
	private PImage arbusto;
	private PImage arbustoDoble;
	
	public Arbusto(PApplet app) {
		this.xA=600;
		this.yA=225;
		this.arbusto= app.loadImage("arbusto1.png");
		this.arbustoDoble= app.loadImage("arbustoDoble.png");
		
		
	}
	public void pintarArbusto1 (PApplet app) {
		app.image(arbusto, xA, yA);
	}

}
