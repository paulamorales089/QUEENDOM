import processing.core.PApplet;
import processing.core.PImage;

public class Sunny {
	private int xS;
	private int yS;
	private boolean pasar;
	private boolean mostrar;

	private PImage suniFrente;
	private PImage suniEspalda;
	private PImage suniDerecha;
	private PImage sunnyIzquierda;
	private PImage suniEspadaDer;
	private PImage suniEspadaIzq;

	public Sunny(PApplet app) {
		this.xS = 74;
		this.yS = 490;

		mostrar = true;
		/*
		 * suniFrente = app.loadImage("sunnyFrente.png"); suniEspalda =
		 * app.loadImage("sunnyEspalda.png");
		 */
		suniDerecha = app.loadImage("sunnyDerecha.png");
		/*
		 * sunnyIzquierda = app.loadImage("sunnyIzquierda.png"); suniEspadaDer =
		 * app.loadImage("suniEspadaDer.png"); suniEspadaIzq =
		 * app.loadImage("suniEspadaIzq.png");
		 */
	}

	/*
	 * public void pintarFrenteSunny(PApplet app) { suniFrente.resize(0,75);
	 * app.image(suniFrente, xS, yS);
	 */

	public void pintarFrenteSunny(PApplet app) {
		app.imageMode(app.CENTER);
		suniDerecha.resize(0, 75);
		app.image(suniDerecha, xS, yS);
		app.imageMode(app.CORNER);
	}
	/*
	 * if(app.keyPressed) { if(app.key == 'w' || app.key=='W') { // arriba
	 * 
	 * suniEspalda.resize(0,75); app.image(suniEspalda, xS, yS);
	 * 
	 * }else if (app.key=='s'||app.key=='S') { //abajo app.image(suniFrente, xS,
	 * yS);
	 * 
	 * }else if(app.key == 'd' || app.key == 'D') { //derecha
	 * suniDerecha.resize(0,75); app.image(suniDerecha, xS, yS);
	 * 
	 * }else if (app.key == 'a' || app.key == 'A') { //izquierda
	 * sunnyIzquierda.resize(0,75); app.image(sunnyIzquierda, xS, yS);
	 * 
	 * } else { app.image(suniFrente, xS, yS); } }else{ suniFrente.resize(0,75);
	 * app.image(suniFrente, xS, yS); }
	 * 
	 * }
	 */

	public void moverSunny(PApplet app) {
		/*
		 * if (app.keyPressed) { switch (app.key) {
		 * 
		 * case 'W': yS-=30; break;
		 * 
		 * case 'w': yS-=30; break;
		 * 
		 * case 'A': xS-=30; break;
		 * 
		 * case 'a': xS-=30; break;
		 * 
		 * case 'S':
		 * 
		 * yS+=30; break;
		 * 
		 * case 's':
		 * 
		 * yS+=30; break;
		 * 
		 * case 'D':
		 * 
		 * xS+=30; break;
		 * 
		 * case 'd':
		 * 
		 * xS+=30; break;
		 * 
		 * 
		 * default: break;
		 * 
		 * } }
		 */

	}

	public void moverArriba() {

		yS -= 30;
	}

	public void moverAbajo() {

		yS += 30;
	}

	public void moverAdelante() {

		xS += 30;
	}

	public void moverAtras() {

		xS -= 30;
	}

	public int getxS() {
		return xS;
	}

	public int getyS() {
		return yS;
	}

}
