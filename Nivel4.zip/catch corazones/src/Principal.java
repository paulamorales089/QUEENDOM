import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Principal extends PApplet{


	
	public static void main(String[] args) {
		PApplet.main("Principal");
	}
		
	
	@Override
	public void settings() {
		size(1200,700);
	}
	
	int estado;
	boolean bc;
	PImage fondo;
	
	ArrayList<Recolectores> listaColor;
	ArrayList<Enemigo> listaCabeza;
	
	BolitaNegra capturador;
	Recolectores elementos;
	
	@Override
	public void setup() {
		
		estado = 1;
		bc = true;
		
		listaColor = new ArrayList<Recolectores>();
		listaCabeza = new ArrayList<Enemigo>();
				
		capturador = new BolitaNegra();
		
		fondo = loadImage("NIVEL 4.png");
		
		for (int i = 0; i <24; i++) { 
			int xTemp = (int) random (1200);
			int yTemp = (int) random (200);
			listaColor.add(new Recolectores(this, xTemp, yTemp));
		}
		
		for (int i = 0; i < 9; i++) { 
			int xTemp = (int) random (1200);
			int yTemp = (int) random (200);
			listaCabeza.add(new Enemigo(this, xTemp, yTemp));
		}
		
	}
	
	@Override
	public void draw() {
		
		background(255);
		imageMode(CENTER);
		image(fondo,600,350,1300,700);
		imageMode(CORNER);
		
		
		
		if (estado==1) { //Start Button
			rectMode(CENTER);
			strokeWeight(3);
			fill(255);
			rect(width/2,height/2,150,60);
			fill(0);
			textSize(32);
			textAlign(CENTER);
			text("START",width/2,height/2+10);
		}
		

		
		if (estado==3) { //perdiste
			strokeWeight(3);
			fill(255);
			rect(1100,50,100,40);
			fill(0);
			textSize(20);
			text("PERDISTE PRRA",1100,55);
			
		}
		
		
		
		capturador.pintar(this); //Bola negra
	

		
		for (int i = 0; i < listaColor.size(); i++) { 
			Recolectores actual = listaColor.get(i);
			actual.PintarCorazon(this);
			
			
			if (estado==2) { 
				
				actual.mover();
				
			} 
			
			if (dist(capturador.getX(),capturador.getY(),actual.getX(),actual.getY())<30) {
				capturador.agregarBolita(listaColor.get(i));
				listaColor.remove(i);
			} 
			
		}
		
		
		
		for (int i = 0; i < listaCabeza.size(); i++) {
			Enemigo actual = listaCabeza.get(i);
			actual.PintarCabeza(this);
			
			if (estado==2) { 
				
				actual.mover();
				
			} 
			
			if (dist(capturador.getX(),capturador.getY(),actual.getX(),actual.getY())< 30) {
				capturador.agregarCabeza(listaCabeza.get(i));
				listaCabeza.remove(i);
				
				estado = 3;
			}
			
			
		}
		
	}
	
	@Override
	public void mousePressed() {
		if (mouseX > width/2 - 60 && mouseX < width/2 + 60 && mouseY > height/2 - 60 && mouseY < height/2+60) {
			estado = 2; 
		}
		
	
		
		
	}

	@Override
	public void mouseMoved() {
		
		if (estado==2) { 
			
			capturador.setX(mouseX);
			
			if (capturador.getX()<0) {
				
				capturador.setX(0);
			} 
			
			if (capturador.getX()>1200) {
				
				
				capturador.setX(1200);
			}
		} 
		
		
	}
	
	
	
}
