import processing.core.PApplet;
import processing.core.PImage;

public class Recolectores {

	private int x , y;
	
	private PImage Corazon; //Cabeza;
	
	private int velocidad;
	
	public Recolectores(PApplet app, int x, int y) {
		
		Corazon = app.loadImage("data/corazon.png");
		//Cabeza = app.loadImage("data/cabeza.png");
		
		this.x = x;
		this.y = y;
	
		velocidad = (int)(Math.random()*(7-1)+2);
	}
	
	public void PintarCorazon(PApplet app) {
		
		app.image(Corazon, x, y, 50, 50);
		//app.fill(r,g,b);
		//app.circle(x, y, diametro);
	}
	
	
	
	public void pintarCorazon(PApplet app, int dx, int dy) {
		
		app.image(Corazon, dx, dy);
		//app.fill(r,g,b);
		//app.circle(dx, dy, diametro/2);
	}
	
	/*public void PintarCabeza(PApplet app) {
		
		app.image(Cabeza, x+4, y+4, 50, 50);
		//app.fill(r,g,b);
		//app.circle(x, y, diametro);
	}
	
	public void pintarCabeza(PApplet app, int dx, int dy) {
		
		app.image(Cabeza, dx+4, dy+4, 50, 50);
		//app.fill(r,g,b);
		//app.circle(dx, dy, diametro/2);
	}*/
	
	public void mover() {
		y+=velocidad;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
}
