import java.util.ArrayList;

import processing.core.PApplet;

public class BolitaNegra {

	private int x;
	private int y;
	private int diametro;
	private int dist;
	private int xDist;
	private ArrayList<Recolectores> corazonLado ; //ArrayList<Recolectores> cabezaLado; 
	private ArrayList<Enemigo> cabezaLado;
	
	public BolitaNegra() {
		this.x = 600;
		this.y = 530;
		this.diametro = 80;
		this.diametro = 60;
		this.dist = 35;
		this.corazonLado = new ArrayList<Recolectores>();
		this.cabezaLado = new ArrayList<Enemigo>();
		
	}
	
	public void pintar (PApplet app) {
		app.fill(0);
		app.circle(x, y, diametro);
		
		for (int i = 0; i < corazonLado.size(); i++) {
			if (i%2==0) {
				xDist = x+(dist+10)+(i*dist);
			} else {
				xDist = x-(dist-60)-(i*dist);
			}
			corazonLado.get(i).pintarCorazon(app, xDist, y);
			
		}
	
		for (int i = 0; i < cabezaLado.size(); i++) {
			if (i%2==0) {
				xDist = x+(dist+10)+(i*dist);
			} else {
				xDist = x-(dist-60)-(i*dist);
			}
			cabezaLado.get(i).pintarCabeza(app, xDist, y);
			
		}
		
	}
	
	public void agregarBolita (Recolectores ref) {
		corazonLado.add(ref);
	}
	
	public void agregarCabeza (Enemigo ref) {
		cabezaLado.add(ref);
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getDiametro() {
		return diametro;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
}
